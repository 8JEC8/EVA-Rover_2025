// src/components/ChartsColumn.tsx
import React, { useMemo } from "react";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Legend,
  Tooltip,
  Filler,
  TimeSeriesScale,
} from "chart.js";
import type { TelemetryRow } from "../types";

ChartJS.register(
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Legend,
  Tooltip,
  Filler,
  TimeSeriesScale
);

type ChartsColumnProps = {
  rows: TelemetryRow[];
  windowSec?: number; // default 10 s
};

// ==========================
// Unidades
// ==========================

// Normaliza unidades para que coincida con TelemetryColumn
function normalizeValue(key: string, raw: number): number {
  const k = key.toLowerCase();

  // Temperaturas: 2845 -> 28.45 °C
  if (k.includes("temp") || k === "t1" || k === "t2") {
    return raw / 100;
  }

  // Humedad: 6261 -> 62.61 %
  if (k.includes("hum")) {
    return raw / 100;
  }

  // Voltajes en mV -> V
  if (
    k === "v" ||
    k.includes("volt") ||
    k.includes("vbatt") ||
    k.includes("vbus") ||
    k.startsWith("v_") ||
    k.endsWith("_v")
  ) {
    return raw / 1000;
  }

  // Corrientes en mA -> A
  if (
    k === "i" ||
    k.includes("current") ||
    k.startsWith("i_") ||
    k.endsWith("_i")
  ) {
    return raw / 1000;
  }

  // Potencias en mW -> W
  if (
    k === "p" ||
    k.includes("power") ||
    k.endsWith("_w") ||
    k.includes("mw")
  ) {
    return raw / 1000;
  }

  // Distancias / demás se quedan igual
  return raw;
}

// ==========================
// Colores para series (uno por métrica de telemetría)
// ==========================
const SERIES_COLORS: Record<string, string> = {
  // Intensidad de señal
  rssi: "#22c55e", // green-500
  avg_rssi: "#16a34a", // green-600

  // Temperaturas
  temp1: "#fb923c", // orange-400
  temp2: "#f97316", // orange-500

  // Humedades
  hum1: "#38bdf8", // sky-400
  hum2: "#0ea5e9", // sky-500

  // ESP (bus principal)
  v_esp: "#a855f7", // purple-500
  i_esp: "#eab308", // yellow-500
  p_esp: "#facc15", // yellow-400

  // Motor 1
  v_m1: "#f97316", // orange-500
  i_m1: "#ea580c", // orange-600
  p_m1: "#fed7aa", // orange-200

  // Motor 2
  v_m2: "#ef4444", // red-500
  i_m2: "#b91c1c", // red-700
  p_m2: "#fecaca", // red-200

  // Aceleraciones
  acc_x: "#22c55e", // green-500
  acc_y: "#84cc16", // lime-500
  acc_z: "#4ade80", // green-400

  // Giroscopio
  gyro_x: "#6366f1", // indigo-500
  gyro_y: "#8b5cf6", // violet-500
  gyro_z: "#0ea5e9", // sky-500

  // Distancias
  dist1: "#38bdf8", // sky-400
  dist2: "#22c55e", // green-500
  dist3: "#e879f9", // fuchsia-400,
};

function colorForKey(key: string, _idx: number): string {
  // _idx se mantiene en la firma para no romper llamadas,
  // pero ya no lo usamos: cada key tiene su color fijo.
  return SERIES_COLORS[key] ?? "#9ca3af"; // gris por si llega alguna llave inesperada
}

// ==========================
// Grupos fijos de llaves por gráfica
// ==========================
const DISTANCE_KEYS = ["dist1", "dist2", "dist3"];
const CURRENT_KEYS = ["i_esp", "i_m1", "i_m2"];
const VOLTAGE_KEYS = ["v_esp", "v_m1", "v_m2"];
const TEMPERATURE_KEYS = ["temp1", "temp2"];

// Tipo interno: fila con timestamp ya normalizado en ms
type RowWithTs = TelemetryRow & { __ts_ms: number };

export default function ChartsColumn({
  rows,
  windowSec = 10,
}: ChartsColumnProps) {
  // ==========================
  // Timestamp por fila (ya viene en row.ts en ms)
  // ==========================
  const rowsWithTs = useMemo<RowWithTs[]>(() => {
    if (!rows || rows.length === 0) return [];
    return rows
      .map((r) => {
        const ts = typeof r.ts === "number" ? r.ts : NaN;
        if (!Number.isFinite(ts)) return null;
        return { ...r, __ts_ms: ts };
      })
      .filter((r): r is RowWithTs => r !== null);
  }, [rows]);

  // Recorta a los últimos windowSec segundos y ordena ascendente
  const windowed = useMemo<RowWithTs[]>(() => {
    if (rowsWithTs.length === 0) return [];
    const lastTs = rowsWithTs.reduce(
      (max, r) => (r.__ts_ms > max ? r.__ts_ms : max),
      rowsWithTs[0].__ts_ms
    );
    const from = lastTs - windowSec * 1000;
    const filtered = rowsWithTs.filter((r) => r.__ts_ms >= from);
    filtered.sort((a, b) => a.__ts_ms - b.__ts_ms);
    return filtered;
  }, [rowsWithTs, windowSec]);

  // Eje X: tiempo relativo (s) a la última muestra
  const labels = useMemo(() => {
    if (windowed.length === 0) return [];
    const last = windowed[windowed.length - 1].__ts_ms;
    return windowed.map((r) => ((r.__ts_ms - last) / 1000).toFixed(2));
  }, [windowed]);

  // ==========================
  // Filtrar llaves que realmente tengan datos numéricos
  // ==========================
  function filterExistingKeys(keys: string[]): string[] {
    if (windowed.length === 0) return [];
    return keys.filter((k) =>
      windowed.some(
        (r) => typeof r[k] === "number" && !Number.isNaN(r[k] as number)
      )
    );
  }

  // ==========================
  // Construcción de datasets
  // ==========================
  function buildDatasets(keys: string[]) {
    return keys.map((k, idx) => {
      const color = colorForKey(k, idx);
      const data = windowed.map((r) => {
        const raw = r[k];
        if (typeof raw !== "number" || Number.isNaN(raw)) return null;
        return normalizeValue(k, raw);
      });

      return {
        label: k,
        data,
        spanGaps: true as const,
        tension: 0.2,
        pointRadius: 0,
        borderWidth: 2,
        fill: false,
        borderColor: color,
      };
    });
  }

  const baseOptions: any = {
    responsive: true,
    maintainAspectRatio: false,
    animation: false,
    plugins: {
      legend: {
        display: true,
        labels: {
          color: "#e5e7eb",
        },
      },
      tooltip: { mode: "nearest", intersect: false },
    },
    scales: {
      x: {
        title: {
          display: true,
          text: "Time (s, relative to last sample)",
          color: "#e5e7eb",
        },
        ticks: { maxRotation: 0, color: "#9ca3af" },
        grid: { display: true, color: "#111827" },
      },
      y: {
        grid: { display: true, color: "#111827" },
        ticks: { maxRotation: 0, color: "#9ca3af" },
      },
    },
    elements: {
      line: { cubicInterpolationMode: "monotone" },
    },
  };

  // ===== Distancia =====
  const distanceKeys = filterExistingKeys(DISTANCE_KEYS);
  const distanceData = {
    labels,
    datasets: buildDatasets(distanceKeys),
  };

  // ===== Corriente =====
  const currentKeys = filterExistingKeys(CURRENT_KEYS);
  const currentData = {
    labels,
    datasets: buildDatasets(currentKeys),
  };

  // ===== Voltaje =====
  const voltageKeys = filterExistingKeys(VOLTAGE_KEYS);
  const voltageData = {
    labels,
    datasets: buildDatasets(voltageKeys),
  };

  // ===== Temperatura =====
  const temperatureKeys = filterExistingKeys(TEMPERATURE_KEYS);
  const temperatureData = {
    labels,
    datasets: buildDatasets(temperatureKeys),
  };

  const warnStyle: React.CSSProperties = {
    color: "#9ca3af",
    fontSize: 12,
    marginTop: 4,
  };

  return (
    <div
      style={{
        display: "grid",
        gridTemplateRows:
          "minmax(160px, 1fr) minmax(160px, 1fr) minmax(160px, 1fr) minmax(160px, 1fr)",
        gap: 12,
        minHeight: 0,
      }}
    >
      {/* Distance */}
      <div style={card}>
        <div style={cardHeader}>
          <strong>Distance (last {windowSec}s)</strong>
        </div>
        <div style={cardBody}>
          {distanceKeys.length ? (
            <Line data={distanceData} options={baseOptions} />
          ) : (
            <em style={warnStyle}>
              No distance keys detected: {DISTANCE_KEYS.join(", ")}
            </em>
          )}
        </div>
      </div>

      {/* Current */}
      <div style={card}>
        <div style={cardHeader}>
          <strong>Current (last {windowSec}s)</strong>
        </div>
        <div style={cardBody}>
          {currentKeys.length ? (
            <Line data={currentData} options={baseOptions} />
          ) : (
            <em style={warnStyle}>
              No current keys detected: {CURRENT_KEYS.join(", ")}
            </em>
          )}
        </div>
      </div>

      {/* Voltage */}
      <div style={card}>
        <div style={cardHeader}>
          <strong>Voltage (last {windowSec}s)</strong>
        </div>
        <div style={cardBody}>
          {voltageKeys.length ? (
            <Line data={voltageData} options={baseOptions} />
          ) : (
            <em style={warnStyle}>
              No voltage keys detected: {VOLTAGE_KEYS.join(", ")}
            </em>
          )}
        </div>
      </div>

      {/* Temperature */}
      <div style={card}>
        <div style={cardHeader}>
          <strong>Temperature (last {windowSec}s)</strong>
        </div>
        <div style={cardBody}>
          {temperatureKeys.length ? (
            <Line data={temperatureData} options={baseOptions} />
          ) : (
            <em style={warnStyle}>
              No temperature keys detected: {TEMPERATURE_KEYS.join(", ")}
            </em>
          )}
        </div>
      </div>
    </div>
  );
}

// ==========================
// Estilos mínimos
// ==========================
const card: React.CSSProperties = {
  border: "1px solid #1f2937",
  borderRadius: 12,
  background: "#0b1220",
  minHeight: 0,
  display: "flex",
  flexDirection: "column",
  overflow: "hidden",
};

const cardHeader: React.CSSProperties = {
  padding: 8,
  borderBottom: "1px solid #1f2937",
};

const cardBody: React.CSSProperties = {
  padding: 8,
  flex: 1,
  minHeight: 0,
};
