// src/components/PanelColumns.tsx
import React from "react";
import ChartsColumn from "./ChartsColumn";
import TelemetryColumn from "./TelemetryColumn";
import VisualColumn from "./VisualColumn";
import type {
  TelemetryRow,
  WebSocketStatus,
  ImageVariants,
} from "../types";

// Componente layout que recibe las filas de telemetría
// y las distribuye entre las tres columnas.
type PanelColumnsProps = {
  rows: TelemetryRow[];
  wsStatus: WebSocketStatus;      // estado del WS, viene de useWebSocketFeed
  imageDataUrl?: string;          // imagen de la cámara (data URL) — variante "procesada"
  imageVariants?: ImageVariants;  // { raw, colors, yolo } desde el backend

  // NUEVO: control .GO / .STOP para telemetría
  telemetryEnabled?: boolean;
  onToggleTelemetry?: () => void;
};

export default function PanelColumns({
  rows,
  wsStatus,
  imageDataUrl,
  imageVariants,
  telemetryEnabled,
  onToggleTelemetry,
}: PanelColumnsProps) {
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns:
          "minmax(320px, 1.2fr) minmax(260px, 1fr) minmax(260px, 1fr)",
        gap: 12,
        minHeight: 0,
        height: "100%",
      }}
    >
      {/* Columna 1: Gráficas */}
      <div
        style={{
          border: "1px solid #1f2937",
          borderRadius: 12,
          background: "#0b1220",
          minHeight: 0,
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
        }}
      >
        <div style={{ padding: 8, borderBottom: "1px solid #1f2937" }}>
          <strong>Charts</strong>
        </div>
        <div style={{ flex: 1, minHeight: 0, overflow: "auto" }}>
          <ChartsColumn rows={rows} />
        </div>
      </div>

      {/* Columna 2: Telemetría */}
      <div
        style={{
          border: "1px solid #1f2937",
          borderRadius: 12,
          background: "#0b1220",
          minHeight: 0,
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
        }}
      >
        <div style={{ padding: 8, borderBottom: "1px solid #1f2937" }}>
          <strong>Telemetry</strong>
        </div>
        <div style={{ flex: 1, minHeight: 0, overflow: "auto" }}>
          {/* TelemetryColumn ahora también recibe:
              - telemetryEnabled
              - onToggleTelemetry */}
          <TelemetryColumn
            rows={rows}
            status={wsStatus}
            telemetryEnabled={telemetryEnabled}
            onToggleTelemetry={onToggleTelemetry}
          />
        </div>
      </div>

      {/* Columna 3: Visual (Webots + cámara + WASD + monitor serial lateral) */}
      <div
        style={{
          border: "1px solid #1f2937",
          borderRadius: 12,
          background: "#0b1220",
          minHeight: 0,
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
        }}
      >
        <div style={{ padding: 8, borderBottom: "1px solid #1f2937" }}>
          <strong>Visuals</strong>
        </div>
        <div style={{ flex: 1, minHeight: 0, overflow: "auto" }}>
          <VisualColumn
            imageDataUrl={imageDataUrl}
            imageVariants={imageVariants}
          />
        </div>
      </div>
    </div>
  );
}
