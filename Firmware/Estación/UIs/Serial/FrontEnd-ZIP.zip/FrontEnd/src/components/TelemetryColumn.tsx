// src/components/TelemetryColumn.tsx
import React, { useMemo, useState } from "react";
import type { TelemetryRow, WebSocketStatus } from "../types";

/* ===================== Tipos de props ===================== */

type TelemetryColumnProps = {
  /** Filas de telemetría ya procesadas por useWebSocketFeed */
  rows: TelemetryRow[];
  /** Estado actual del WebSocket (para el semáforo) */
  status: WebSocketStatus;
  /** NUEVO: ¿está activo el stream de telemetría (.GO / .STOP)? */
  telemetryEnabled?: boolean;
  /** NUEVO: callback para alternar .GO / .STOP */
  onToggleTelemetry?: () => void;
};

/* ===================== Helpers numéricos ===================== */

/** Convierte a número si se puede, o undefined si no aplica */
function toNumberOrUndefined(v: unknown): number | undefined {
  if (v === null || v === undefined) return undefined;
  if (typeof v === "number" && isFinite(v)) return v;
  if (typeof v === "string") {
    const m = v.match(/-?\d+(\.\d+)?/);
    if (m) return Number(m[0]);
  }
  return undefined;
}

/** Formatea un valor numérico genérico con unidad opcional */
function fmt(v: unknown, unit?: string, digits = 2): string {
  const n = toNumberOrUndefined(v);
  if (n === undefined) return "–";
  return unit ? `${n.toFixed(digits)} ${unit}` : n.toFixed(digits);
}

/**
 * Temperaturas / humedades vienen *x100* (ej. 2845 → 28.45)
 */
function fmtScaled100(v: unknown, unit?: string, digits = 2): string {
  const n = toNumberOrUndefined(v);
  if (n === undefined) return "–";
  const scaled = n / 100;
  return unit ? `${scaled.toFixed(digits)} ${unit}` : scaled.toFixed(digits);
}

/* ===================== UI atómica ===================== */

function StatusDot({ status }: { status: WebSocketStatus }) {
  const color =
    status === "open"
      ? "#10b981" // verde
      : status === "connecting"
      ? "#f59e0b" // amarillo
      : status === "error"
      ? "#ef4444" // rojo
      : status === "closed"
      ? "#6b7280" // gris oscuro
      : "#9ca3af"; // gris claro (idle / otros)

  return (
    <span
      title={status}
      style={{
        display: "inline-block",
        width: 10,
        height: 10,
        borderRadius: 999,
        background: color,
        marginRight: 8,
      }}
    />
  );
}

function LineKV({ k, v }: { k: string; v: string }) {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        gap: 8,
        padding: "2px 0",
      }}
    >
      <span>{k}</span>
      <span style={{ color: "#e5e7eb" }}>{v}</span>
    </div>
  );
}

/* ===================== Estilos de tarjeta ===================== */

const card: React.CSSProperties = {
  border: "1px solid #1f2937",
  borderRadius: 12,
  background: "#0b1220",
  minHeight: 0,
  overflow: "hidden",
};

const cardHeader: React.CSSProperties = {
  padding: "10px 12px",
  borderBottom: "1px solid #1f2937",
};

const cardBody: React.CSSProperties = {
  padding: "10px 12px",
  display: "flex",
  flexDirection: "column",
  gap: 2,
};

const cardGrid2: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "1fr 1fr",
  gap: 10,
};

const btnBase: React.CSSProperties = {
  padding: "6px 10px",
  borderRadius: 8,
  border: "1px solid #374151",
  background: "#0a0f1a",
  color: "#e5e7eb",
  cursor: "pointer",
};

const btnStyle: React.CSSProperties = { ...btnBase };

/* ===================== Componente principal ===================== */

export default function TelemetryColumn({
  rows,
  status,
  telemetryEnabled,
  onToggleTelemetry,
}: TelemetryColumnProps) {
  const [showJSON, setShowJSON] = useState(false);

  // Última fila de telemetría disponible
  const latest = useMemo(() => {
    if (!rows || rows.length === 0) return undefined;
    // sueles acumular en orden -> la última es la más reciente
    return rows[rows.length - 1];
  }, [rows]);

  /* ===================== Vista sin datos ===================== */

  if (!latest) {
    return (
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          minHeight: 0,
          height: "100%",
        }}
      >
        {/* Header */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
            padding: "8px 12px",
            borderBottom: "1px solid #1f2937",
            background: "#0b1220",
          }}
        >
          <StatusDot status={status} />
          <strong>Telemetry</strong>
          <div
            style={{
              marginLeft: "auto",
              display: "flex",
              gap: 8,
            }}
          >
            {/* NUEVO: botón .GO / .STOP aun si no hay datos */}
            <button
              onClick={onToggleTelemetry}
              disabled={!onToggleTelemetry}
              style={{
                ...btnBase,
                borderColor: telemetryEnabled ? "#16a34a" : "#374151",
                background: telemetryEnabled ? "#065f46" : "#0a0f1a",
              }}
            >
              {telemetryEnabled ? "STOP TELEMETRY" : "START TELEMETRY"}
            </button>

            <button
              onClick={() => setShowJSON((s) => !s)}
              style={btnStyle}
              disabled
            >
              View JSON
            </button>
          </div>
        </div>

        <div
          style={{
            padding: 12,
            color: "#9ca3af",
            fontSize: 14,
          }}
        >
          No telemetry data yet…
        </div>
      </div>
    );
  }

  /* ===================== Vista con datos ===================== */

  // Timestamp: latest.ts está en ms (desde useWebSocketFeed)
  const tsLabel = new Date(latest.ts).toISOString();

  // Campos fijos de TelemetryRover -> mismos nombres en TelemetryRow
  const {
    rssi,
    avg_rssi,
    temp1,
    hum1,
    temp2,
    hum2,
    v_esp,
    i_esp,
    p_esp,
    v_m1,
    i_m1,
    p_m1,
    v_m2,
    i_m2,
    p_m2,
    acc_x,
    acc_y,
    acc_z,
    gyro_x,
    gyro_y,
    gyro_z,
    dist1,
    dist2,
    dist3,
    // ts ya lo usamos arriba
  } = latest;

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        minHeight: 0,
        height: "100%",
      }}
    >
      {/* Header */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 8,
          padding: "8px 12px",
          borderBottom: "1px solid #1f2937",
          background: "#0b1220",
        }}
      >
        <StatusDot status={status} />
        <strong>Telemetry</strong>
        <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
          {/* NUEVO: botón .GO / .STOP */}
          <button
            onClick={onToggleTelemetry}
            disabled={!onToggleTelemetry}
            style={{
              ...btnBase,
              borderColor: telemetryEnabled ? "#16a34a" : "#374151",
              background: telemetryEnabled ? "#065f46" : "#0a0f1a",
            }}
          >
            {telemetryEnabled ? "Stop Telemetry" : "Start Telemetry"}
          </button>

          <button onClick={() => setShowJSON((s) => !s)} style={btnStyle}>
            {showJSON ? "Hide JSON" : "View JSON"}
          </button>
        </div>
      </div>

      {/* Body */}
      <div
        style={{
          padding: 10,
          display: "grid",
          gridTemplateRows:
            "auto auto auto auto auto" + (showJSON ? " auto" : ""),
          gap: 10,
          overflow: "auto",
          minHeight: 0,
        }}
      >
        {/* Tiempo / Señal */}
        <div style={cardGrid2}>
          <div style={card}>
            <div style={cardHeader}>
              <strong>Time</strong>
            </div>
            <div style={cardBody}>
              <LineKV k="ts:" v={tsLabel} />
            </div>
          </div>
          <div style={card}>
            <div style={cardHeader}>
              <strong>Signal</strong>
            </div>
            <div style={cardBody}>
              <LineKV k="Rssi:" v={fmt(rssi, "dBm", 0)} />
              <LineKV k="avgRssi:" v={fmt(avg_rssi, "dBm", 0)} />
            </div>
          </div>
        </div>

        {/* Temperaturas y Humedades */}
        <div style={card}>
          <div style={cardHeader}>
            <strong>Temperatures and Humidity</strong>
          </div>
          <div style={cardBody}>
            <LineKV k="Temp 1:" v={fmtScaled100(temp1, "°C")} />
            <LineKV k="Hum 1:" v={fmtScaled100(hum1, "%")} />
            <LineKV k="Temp 2:" v={fmtScaled100(temp2, "°C")} />
            <LineKV k="Hum 2:" v={fmtScaled100(hum2, "%")} />
          </div>
        </div>

        {/* Voltajes y Corrientes */}
        <div style={card}>
          <div style={cardHeader}>
            <strong>Voltages and Currents</strong>
          </div>
          <div style={cardBody}>
            <div style={{ marginBottom: 6, color: "#9ca3af" }}>
              <strong>ESP</strong>
            </div>
            {/* Ahora en mV, mA, mW según tu convención */}
            <LineKV k="V Esp:" v={fmt(v_esp, "mV")} />
            <LineKV k="I Esp:" v={fmt(i_esp, "mA")} />
            <LineKV k="P Esp:" v={fmt(p_esp, "mW")} />
            <div
              style={{
                margin: "8px 0 6px",
                color: "#9ca3af",
              }}
            >
              <strong>Motors</strong>
            </div>
            <LineKV k="V M1:" v={fmt(v_m1, "mV")} />
            <LineKV k="I M1:" v={fmt(i_m1, "mA")} />
            <LineKV k="P M1:" v={fmt(p_m1, "mW")} />
            <LineKV k="V M2:" v={fmt(v_m2, "mV")} />
            <LineKV k="I M2:" v={fmt(i_m2, "mA")} />
            <LineKV k="P M2:" v={fmt(p_m2, "mW")} />
          </div>
        </div>

        {/* IMU */}
        <div style={card}>
          <div style={cardHeader}>
            <strong>IMU</strong>
          </div>
          <div style={cardBody}>
            <div style={{ marginBottom: 6, color: "#9ca3af" }}>
              <strong>Gyro</strong>
            </div>
            <LineKV k="gyro X:" v={fmt(gyro_x)} />
            <LineKV k="gyro Y:" v={fmt(gyro_y)} />
            <LineKV k="gyro Z:" v={fmt(gyro_z)} />
            <div
              style={{
                margin: "8px 0 6px",
                color: "#9ca3af",
              }}
            >
              <strong>Acc</strong>
            </div>
            <LineKV k="acc X:" v={fmt(acc_x)} />
            <LineKV k="acc Y:" v={fmt(acc_y)} />
            <LineKV k="acc Z:" v={fmt(acc_z)} />
          </div>
        </div>

        {/* Distancias */}
        <div style={card}>
          <div style={cardHeader}>
            <strong>Distances</strong>
          </div>
          <div style={cardBody}>
            <LineKV k="Dist 1:" v={fmt(dist1)} />
            <LineKV k="Dist 2:" v={fmt(dist2)} />
            <LineKV k="Dist 3:" v={fmt(dist3)} />
          </div>
        </div>

        {/* Inspector JSON (debug) */}
        {showJSON && (
          <div style={card}>
            <div style={cardHeader}>
              <strong>Last payload (debug)</strong>
            </div>
            <div
              style={{
                ...cardBody,
                whiteSpace: "pre",
                fontFamily:
                  "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace",
              }}
            >
              {JSON.stringify(latest, null, 2)}
            </div>
          </div>
        )}
      </div>

      {/* Footer simple */}
      <div
        style={{
          padding: "6px 12px",
          fontSize: 12,
          color: "#9ca3af",
          borderTop: "1px solid #1f2937",
          background: "#0b1220",
        }}
      >
        <span>
          WS status: <code>{status}</code>
        </span>
      </div>
    </div>
  );
}
