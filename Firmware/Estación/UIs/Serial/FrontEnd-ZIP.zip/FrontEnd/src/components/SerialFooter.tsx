// src/components/SerialFooter.tsx
import { useEffect, useRef, useState } from "react";
import type { WebSocketStatus } from "../types";

const WS_URL = import.meta.env.VITE_WS_URL ?? "ws://localhost:8000/ws";

type SerialFooterProps = {
  lines: string[];
};

export default function SerialFooter({ lines }: SerialFooterProps) {
  const [open, setOpen] = useState(true);
  const [input, setInput] = useState("");
  const [status, setStatus] = useState<WebSocketStatus>("connecting");
  const [error, setError] = useState<string | null>(null);

  const wsRef = useRef<WebSocket | null>(null);
  const endRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll al final cuando cambian las líneas
  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "auto", block: "end" });
  }, [lines.length]);

  // WebSocket dedicado SOLO para enviar comandos desde el footer
  useEffect(() => {
    let alive = true;

    const connect = () => {
      try {
        const ws = new WebSocket(WS_URL);
        wsRef.current = ws;
        setStatus("connecting");
        setError(null);

        ws.onopen = () => {
          if (!alive) return;
          setStatus("open");
        };

        ws.onerror = () => {
          if (!alive) return;
          setStatus("error");
          setError("Serial monitor WebSocket error");
        };

        ws.onclose = () => {
          if (!alive) return;
          setStatus("closed");
          // reconexión sencilla
          setTimeout(connect, 1000);
        };

        // No necesitamos leer nada aquí. La recepción la hace useWebSocketFeed.
        ws.onmessage = () => {};
      } catch (err) {
        console.error("SerialFooter WS connect error", err);
        if (alive) {
          setStatus("error");
          setError("Could not connect serial monitor WebSocket");
        }
      }
    };

    connect();

    return () => {
      alive = false;
      try {
        wsRef.current?.close();
      } catch {
        /* ignore */
      }
      wsRef.current = null;
    };
  }, []);

  const handleSend = () => {
    const text = input.trim();
    if (!text) return;

    const ws = wsRef.current;
    if (!ws || ws.readyState !== WebSocket.OPEN) {
      setError("WebSocket is not connected");
      return;
    }

    try {
      // Nuevo protocolo: comando serial por WS
      ws.send(
        JSON.stringify({
          type: "serial_write_cmd",
          data: text,
        })
      );
      setInput("");
      setError(null);
    } catch (err) {
      console.error("SerialFooter WS send error", err);
      setError("Error sending command over WebSocket");
    }
  };

  const canSend = status === "open" && input.trim().length > 0;

  return (
    <div
      style={{
        position: "fixed",
        left: 0,
        right: 0,
        bottom: 0,
        zIndex: 60,
        pointerEvents: "none", // contenedor
      }}
    >
      <div
        style={{
          maxWidth: 1400,
          margin: "0 auto",
          padding: "0 12px 12px",
          pointerEvents: "auto", // reactivar dentro
        }}
      >
        <div
          style={{
            background: "#0b1220",
            border: "1px solid #1f2937",
            borderRadius: 12,
            boxShadow: "0 8px 24px rgba(0,0,0,0.4)",
            overflow: "hidden",
          }}
        >
          {/* Header */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "8px 12px",
              background: "#111827",
              borderBottom: "1px solid #1f2937",
              fontSize: 13,
            }}
          >
            <strong>Serial Monitor</strong>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <span
                style={{
                  padding: "2px 8px",
                  borderRadius: 999,
                  fontSize: 11,
                  border: "1px solid #4b5563",
                  color:
                    status === "open"
                      ? "#16a34a"
                      : status === "connecting"
                      ? "#f59e0b"
                      : status === "error"
                      ? "#ef4444"
                      : "#9ca3af",
                }}
              >
                WS: {status.toUpperCase()}
              </span>
              <button
                onClick={() => setOpen((v) => !v)}
                style={{
                  background: "#374151",
                  color: "white",
                  border: "none",
                  padding: "6px 10px",
                  borderRadius: 8,
                  cursor: "pointer",
                  fontSize: 12,
                }}
              >
                {open ? "Hide" : "Show"}
              </button>
            </div>
          </div>

          {open && (
            <>
              {/* Log */}
              <div
                style={{
                  height: 180,
                  overflowY: "auto",
                  fontFamily:
                    "ui-monospace, SFMono-Regular, Menlo, monospace",
                  fontSize: 12,
                  padding: 10,
                  background: "#0a0f1a",
                  borderBottom: "1px solid #1f2937",
                }}
              >
                {lines.length === 0 ? (
                  <div style={{ opacity: 0.7 }}>Waiting for data…</div>
                ) : (
                  lines.slice(-800).map((l, idx) => (
                    <div key={idx} style={{ whiteSpace: "pre-wrap" }}>
                      {l}
                    </div>
                  ))
                )}
                <div ref={endRef} />
              </div>

              {/* Barra de entrada */}
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  padding: "8px 10px 10px",
                  background: "#020617",
                }}
              >
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(ev) => {
                    if (ev.key === "Enter") {
                      ev.preventDefault();
                      handleSend();
                    }
                  }}
                  placeholder="Type a command and press Enter"
                  style={{
                    flex: 1,
                    padding: "6px 10px",
                    borderRadius: 999,
                    border: "1px solid #1f2937",
                    background: "#020617",
                    color: "#e5e7eb",
                    fontSize: 12,
                    outline: "none",
                  }}
                />
                <button
                  onClick={handleSend}
                  disabled={!canSend}
                  style={{
                    padding: "6px 14px",
                    borderRadius: 999,
                    border: "1px solid #22c55e",
                    background: canSend ? "#22c55e" : "#1f2937",
                    color: canSend ? "#020617" : "#9ca3af",
                    fontSize: 12,
                    fontWeight: 600,
                    cursor: canSend ? "pointer" : "not-allowed",
                  }}
                >
                  Send
                </button>
              </div>

              {error && (
                <div
                  style={{
                    padding: "0 10px 8px",
                    background: "#020617",
                    fontSize: 11,
                    color: "#f97373",
                  }}
                >
                  {error}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
