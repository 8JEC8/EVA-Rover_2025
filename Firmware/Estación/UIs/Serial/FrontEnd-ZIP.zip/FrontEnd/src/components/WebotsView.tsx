// src/components/WebotsView.tsx
import React from "react";

const WEBOTS_URL_DEFAULT =
  (import.meta.env.VITE_WEBOTS_URL as string) || "http://localhost:1999";

// ===== estilos pequeños reutilizables (sin Tailwind) =====
const cardStyle: React.CSSProperties = {
  border: "1px solid #1f2937",
  borderRadius: 12,
  background: "#0b1220",
  overflow: "hidden",
  display: "flex",
  flexDirection: "column",
  minHeight: 0,
};

const sectionHeader: React.CSSProperties = {
  padding: 8,
  borderBottom: "1px solid #1f2937",
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
};

const smallText: React.CSSProperties = {
  fontSize: 12,
  color: "#9ca3af",
};

type WebotsViewProps = {
  /** Optional URL for Webots; if not provided, uses VITE_WEBOTS_URL or http://localhost:1999 */
  webotsUrl?: string;
};

const WebotsView: React.FC<WebotsViewProps> = ({ webotsUrl }) => {
  const url = webotsUrl || WEBOTS_URL_DEFAULT;

  return (
    <div style={{ ...cardStyle, flex: 1 }}>
      <div style={sectionHeader}>
        <strong>Webots</strong>
        <span style={smallText}>Local simulation</span>
      </div>

      <div style={{ flex: 1, minHeight: 0 }}>
        <div
          style={{
            width: "100%",
            height: "100%",
            minHeight: 220,
            borderTop: "1px solid #0f172a",
          }}
        >
          <iframe
            src={url}
            style={{ width: "100%", height: "100%", border: "none" }}
            allowFullScreen
            title="WebotsStream"
          />
        </div>
      </div>

      <div
        style={{
          padding: "6px 12px",
          borderTop: "1px solid #1f2937",
          ...smallText,
          display: "flex",
          justifyContent: "space-between",
          gap: 8,
        }}
      >
        <span>Source: Webots (local)</span>
        <span style={{ opacity: 0.8 }}>
          URL: <code>{url}</code>
        </span>
      </div>
    </div>
  );
};

export default WebotsView;
