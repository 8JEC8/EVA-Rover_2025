// src/components/CameraPanel.tsx
import React, { useEffect, useMemo, useState } from "react";
import type { WebSocketStatus, ImageVariants } from "../types";

const cardStyle: React.CSSProperties = {
  border: "1px solid #1f2937",
  borderRadius: 12,
  background: "#0b1220",
  overflow: "hidden",
  display: "flex",
  flexDirection: "column",
};

const sectionHeader: React.CSSProperties = {
  padding: 8,
  borderBottom: "1px solid #1f2937",
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
};

const badgeBase: React.CSSProperties = {
  padding: "2px 8px",
  borderRadius: 8,
  fontSize: 12,
  border: "1px solid",
};

const smallText: React.CSSProperties = {
  fontSize: 12,
  color: "#9ca3af",
};

type ViewMode = "auto" | "raw" | "colors" | "model";

type CameraPanelProps = {
  wsStatus: WebSocketStatus;
  /** Imagen “principal” (compat / fallback): data:image/jpeg;base64,... */
  imageDataUrl?: string;
  /** Variantes que vienen del backend (si existen) */
  imageVariants?: ImageVariants;
  /** Función para mandar comandos por WS (ya hace el JSON.stringify en el padre) */
  sendCommand: (msg: any) => void;
};

const CameraPanel: React.FC<CameraPanelProps> = ({
  wsStatus,
  imageDataUrl,
  imageVariants,
  sendCommand,
}) => {
  const [isCapturing, setIsCapturing] = useState(false);
  const [lastFrame, setLastFrame] = useState<string | null>(null);
  const [frameMime, setFrameMime] = useState<string>("image/jpeg");

  // auto = elige la mejor disponible (model/yolo > colors > raw > imageDataUrl)
  const [viewMode, setViewMode] = useState<ViewMode>("auto");

  const hasRaw = !!imageVariants?.raw;
  const hasColors = !!imageVariants?.colors;

  // Usamos "yolo" como variante de modelo
  const modelVariant: string | undefined = imageVariants?.yolo;
  const hasModel = !!modelVariant;

  // Decide qué imagen mostrar según el modo seleccionado + lo que haya disponible
  useEffect(() => {
    let src: string | undefined;

    if (imageVariants) {
      if (viewMode === "raw" && imageVariants.raw) {
        src = imageVariants.raw;
      } else if (viewMode === "colors" && imageVariants.colors) {
        src = imageVariants.colors;
      } else if (viewMode === "model" && modelVariant) {
        // Variante de modelo (YOLO u otro)
        src = modelVariant;
      } else {
        // Modo auto o faltan variantes -> elegimos en orden de preferencia:
        // modelo > colores > raw
        if (modelVariant) src = modelVariant;
        else if (imageVariants.colors) src = imageVariants.colors;
        else if (imageVariants.raw) src = imageVariants.raw;
      }
    }

    // Si no hubo variantes o nada válido, usamos imageDataUrl como fallback
    if (!src && imageDataUrl) {
      src = imageDataUrl;
    }

    if (!src) return;

    setLastFrame(src);
    // Si estábamos en "Tomando...", ya llegó algo: dejamos de capturar
    setIsCapturing(false);

    const m = /^data:(.+?);base64,/.exec(src);
    setFrameMime(m ? m[1] : "image/jpeg");
  }, [imageDataUrl, imageVariants, viewMode, modelVariant]);

  // BOTÓN SNAPSHOT: toggle .IMAGE / .CANCEL vía telemetry_cmd
  const handleSnapshotClick = () => {
    if (wsStatus !== "open") return;

    if (!isCapturing) {
      // Empezar captura -> .IMAGE
      setIsCapturing(true);
      sendCommand({ type: "telemetry_cmd", action: "image" });
    } else {
      // Cancelar captura -> .CANCEL
      setIsCapturing(false);
      sendCommand({ type: "telemetry_cmd", action: "cancel" });
    }
  };

  const wsBadge = useMemo(() => {
    const base = { ...badgeBase };
    if (wsStatus === "open")
      return (
        <span style={{ ...base, borderColor: "#16a34a", color: "#16a34a" }}>
          WS: OPEN
        </span>
      );
    if (wsStatus === "connecting")
      return (
        <span style={{ ...base, borderColor: "#f59e0b", color: "#f59e0b" }}>
          WS: CONNECTING
        </span>
      );
    if (wsStatus === "error")
      return (
        <span style={{ ...base, borderColor: "#ef4444", color: "#ef4444" }}>
          WS: ERROR
        </span>
      );
    return (
      <span style={{ ...base, borderColor: "#6b7280", color: "#6b7280" }}>
        WS: CLOSED
      </span>
    );
  }, [wsStatus]);

  return (
    <div style={cardStyle}>
      <div style={sectionHeader}>
        <strong>Camera</strong>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
          }}
        >
          {/* Selector de vista */}
          <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
            <span style={{ ...smallText, marginRight: 2 }}>View:</span>
            <select
              value={viewMode}
              onChange={(e) => setViewMode(e.target.value as ViewMode)}
              style={{
                background: "#020617",
                color: "#e5e7eb",
                borderRadius: 8,
                border: "1px solid #334155",
                fontSize: 12,
                padding: "4px 6px",
                outline: "none",
              }}
            >
              <option value="auto">Auto</option>
              <option value="raw" disabled={!hasRaw}>
                Original
              </option>
              <option value="colors" disabled={!hasColors}>
                Colors
              </option>
              <option value="model" disabled={!hasModel}>
                Model
              </option>
            </select>
          </div>

          {wsBadge}

          <button
            onClick={handleSnapshotClick}
            disabled={wsStatus !== "open"}
            style={{
              padding: "6px 10px",
              borderRadius: 8,
              border: "1px solid #334155",
              background: isCapturing ? "#b91c1c" : "#111827",
              color: "#e5e7eb",
              cursor: wsStatus !== "open" ? "not-allowed" : "pointer",
              fontSize: 13,
            }}
          >
            {isCapturing ? "Cancel snapshot" : "Take snapshot"}
          </button>
        </div>
      </div>

      <div
        style={{
          width: "100%",
          background: "#000",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          position: "relative",
          aspectRatio: "16/9",
        }}
      >
        {lastFrame ? (
          // eslint-disable-next-line jsx-a11y/alt-text
          <img
            src={lastFrame}
            alt="camera"
            style={{
              maxWidth: "100%",
              maxHeight: "100%",
              objectFit: "contain",
              display: "block",
            }}
          />
        ) : (
          <div style={{ color: "rgba(255,255,255,0.7)", fontSize: 14 }}>
            No image. Press <b>Take Snapshot</b>.
          </div>
        )}

        {isCapturing && wsStatus === "open" && (
          <div
            style={{
              position: "absolute",
              right: 10,
              top: 10,
              padding: "2px 8px",
              borderRadius: 8,
              background: "rgba(17,24,39,0.9)",
              border: "1px solid #334155",
              color: "#e5e7eb",
              fontSize: 12,
            }}
          >
            Taking...
          </div>
        )}
      </div>

      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "8px 12px",
          borderTop: "1px solid #1f2937",
        }}
      >
        <div style={{ ...smallText }}>
          {viewMode !== "auto" && (
            <span style={{ marginLeft: 8 }}>
              · View:{" "}
              {viewMode === "raw"
                ? "Original"
                : viewMode === "colors"
                ? "Colors"
                : viewMode === "model"
                ? "Model"
                : "Auto"}
            </span>
          )}
        </div>
        {lastFrame && (
          <a
            href={lastFrame}
            download={`snapshot_${Date.now()}.${
              frameMime.split("/")[1] || "jpg"
            }`}
            style={{
              ...smallText,
              textDecoration: "underline",
              cursor: "pointer",
            }}
          >
            Download Snapshot
          </a>
        )}
      </div>
    </div>
  );
};

export default CameraPanel;
