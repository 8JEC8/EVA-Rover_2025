// src/components/Grid10x10.tsx
import React, { useCallback, useEffect, useMemo, useState } from "react";

// Grid lógico 10x10 (matriz del rover)
const GRID_ROWS = 10;
const GRID_COLS = 10;

// Posición inicial del rover (abajo-izquierda)
const START_ROW = GRID_ROWS - 1; // fila inferior (índice 9)
const START_COL = 0; // primera columna (izquierda)

// Dirección del rover
type Direction = "N" | "E" | "S" | "W";

// Pose = posición + orientación (en índices de matriz)
type RoverPose = {
  row: number; // 0 arriba ... 9 abajo
  col: number; // 0 izquierda ... 9 derecha
  dir: Direction;
};

// Estado de cada celda
type Cell = {
  obstacle: boolean;
};

type GoalCell = { row: number; col: number };

type GridProps = {
  /** Línea completa tipo "RECV_ROVER_...,M,2000000000,..." */
  matrixLine?: string | null;
  /** Callback opcional: aquí el padre puede mandar '.CLEARALL' por serial */
  onReset?: () => void;
  /** Último comando enviado por consola, ej: ".GOAL 0 3" */
  goalCommand?: string | null;
  /** Opcional: callback cuando el usuario selecciona una meta con click.
   *  Ahora recibe directamente el comando ".GOAL x y"
   */
  onGoalClick?: (cmd: string) => void;
  /** Estado del modo auto (para el texto del botón) */
  autoEnabled?: boolean;
  /** Callback para activar/detener auto: recibe ".AUTO" / ".STOPAUTO" */
  onToggleAuto?: (cmd: string) => void;
  /** Estado de pausa del auto (.PAUSE / .RESUME) */
  autoPaused?: boolean;
  /** Callback para pausar/reanudar auto: recibe ".PAUSE" / ".RESUME" */
  onTogglePause?: (cmd: string) => void;
};

const initialPose: RoverPose = {
  row: START_ROW,
  col: START_COL,
  dir: "N", // mirando hacia arriba
};

// Origen de coordenadas = posición inicial del rover
const ORIGIN_ROW = initialPose.row;
const ORIGIN_COL = initialPose.col;

function createEmptyGrid(): Cell[][] {
  return Array.from({ length: GRID_ROWS }, () =>
    Array.from({ length: GRID_COLS }, () => ({
      obstacle: false,
    }))
  );
}

// 2,3,4,5 -> N,E,W,S (según la convención actual del firmware)
function codeToDirection(code: number): Direction {
  switch (code) {
    case 2:
      return "N";
    case 3:
      return "E";
    case 4:
      return "W";
    case 5:
      return "S";
    default:
      return "N";
  }
}

/* ===================== A* helpers (en índices row/col) ===================== */

type PathPoint = { row: number; col: number };

function heuristicRC(ar: number, ac: number, br: number, bc: number): number {
  return Math.abs(ar - br) + Math.abs(ac - bc);
}

function runAStarGrid(
  grid: Cell[][],
  start: GoalCell,
  goal: GoalCell
): PathPoint[] {
  const rows = grid.length;
  if (rows === 0) return [];
  const cols = grid[0].length;

  const inBounds = (r: number, c: number) =>
    r >= 0 && r < rows && c >= 0 && c < cols;

  const isBlocked = (r: number, c: number) => {
    const row = grid[r];
    if (!row) return true;
    const cell = row[c];
    if (!cell) return true;
    return !!cell.obstacle;
  };

  // Validar inicio/meta
  if (!inBounds(start.row, start.col) || !inBounds(goal.row, goal.col)) {
    return [];
  }
  if (isBlocked(start.row, start.col) || isBlocked(goal.row, goal.col)) {
    return [];
  }

  const total = rows * cols;
  const idx = (r: number, c: number) => r * cols + c;

  const gScore = new Array<number>(total).fill(Infinity);
  const fScore = new Array<number>(total).fill(Infinity);
  const cameFrom = new Array<number | null>(total).fill(null);
  const closed = new Array<boolean>(total).fill(false);
  const openList: number[] = [];

  const startIdx = idx(start.row, start.col);
  const goalIdx = idx(goal.row, goal.col);

  gScore[startIdx] = 0;
  fScore[startIdx] = heuristicRC(start.row, start.col, goal.row, goal.col);
  openList.push(startIdx);

  const neighbors: [number, number][] = [
    [-1, 0], // arriba
    [0, 1], // derecha
    [1, 0], // abajo
    [0, -1], // izquierda
  ];

  while (openList.length > 0) {
    // Nodo con fScore mínimo
    let bestIndex = 0;
    for (let i = 1; i < openList.length; i++) {
      if (fScore[openList[i]] < fScore[openList[bestIndex]]) {
        bestIndex = i;
      }
    }
    const current = openList[bestIndex];
    openList.splice(bestIndex, 1);

    if (current === goalIdx) {
      // Reconstruir camino
      const revPath: number[] = [];
      let cur: number | null = current;
      while (cur !== null) {
        revPath.push(cur);
        cur = cameFrom[cur] ?? null;
      }
      revPath.reverse();
      return revPath.map((id) => ({
        row: Math.floor(id / cols),
        col: id % cols,
      }));
    }

    if (closed[current]) continue;
    closed[current] = true;

    const curRow = Math.floor(current / cols);
    const curCol = current % cols;

    for (const [dr, dc] of neighbors) {
      const nr = curRow + dr;
      const nc = curCol + dc;
      if (!inBounds(nr, nc)) continue;
      if (isBlocked(nr, nc)) continue;

      const nIdx = idx(nr, nc);
      if (closed[nIdx]) continue;

      const tentativeG = gScore[current] + 1;
      if (tentativeG < gScore[nIdx]) {
        cameFrom[nIdx] = current;
        gScore[nIdx] = tentativeG;
        fScore[nIdx] =
          tentativeG + heuristicRC(nr, nc, goal.row, goal.col);

        if (!openList.includes(nIdx)) {
          openList.push(nIdx);
        }
      }
    }
  }

  // No hay camino
  return [];
}

/* ========================================================================== */
/**
 * Recibe la línea tipo:
 * RECV_ROVER_-45,-44,M,2000000000,0000000000,1000000000,...
 *
 * CONVENCIÓN:
 *  - El PRIMER grupo después de 'M' es la fila INFERIOR del grid.
 *  - El ÚLTIMO grupo es la fila SUPERIOR.
 *
 * Devuelve:
 *  - grid: Cell[][]
 *  - pose: RoverPose con posición/dirección del rover (2/3/4/5)
 */
function parseMatrixLine(
  line: string
): { grid: Cell[][]; pose: RoverPose | null } | null {
  const parts = line.split(",");
  const idxM = parts.indexOf("M");
  if (idxM === -1) return null;

  // Después de la M vienen las filas del grid:
  // rowTokens[0] = fila INFERIOR
  // rowTokens[rowTokens.length - 1] = fila SUPERIOR
  const rowTokens = parts.slice(idxM + 1);
  if (rowTokens.length === 0) return null;

  const numRows = Math.min(rowTokens.length, GRID_ROWS);

  const grid: Cell[][] = [];
  let roverPose: RoverPose | null = null;

  // grid[0] = fila de ARRIBA (como la dibuja el CSS)
  // rowTokens[0] = fila de ABAJO
  for (let visualRow = 0; visualRow < numRows; visualRow++) {
    // tokenIndex recorre las filas de arriba hacia abajo
    const tokenIndex = numRows - 1 - visualRow; // último token -> fila 0 (arriba)

    const rowStr = rowTokens[tokenIndex];
    const trimmed = rowStr.trim();
    if (!trimmed) {
      grid.push(
        Array.from({ length: GRID_COLS }, () => ({
          obstacle: false,
        }))
      );
      continue;
    }

    const chars = Array.from(trimmed); // ["2","0","0",...]
    const rowCells: Cell[] = [];

    chars.forEach((ch, c) => {
      const v = Number(ch);
      const cell: Cell = { obstacle: false };

      if (v === 1) {
        cell.obstacle = true;
      } else if (v >= 2 && v <= 5) {
        // celda donde está el rover
        const dir = codeToDirection(v);
        roverPose = { row: visualRow, col: c, dir };
      }

      rowCells.push(cell);
    });

    grid.push(rowCells);
  }

  return { grid, pose: roverPose };
}

const baseGradient =
  "radial-gradient(circle at 30% 30%, #111827 0, #020617 60%, #000000 100%)";

// índices de matriz -> coords “humanas” (0,0 = posición inicial)
// N (arriba) = y positivo, E (derecha) = x positivo
function toDisplayCoords(pose: RoverPose): { x: number; y: number } {
  const x = pose.col - ORIGIN_COL; // 0 en la col inicial, +1 a la derecha
  const y = ORIGIN_ROW - pose.row; // 0 en la fila inicial, +1 hacia arriba
  return { x, y };
}

// coords humanas (0,0 en origen, y hacia arriba) -> índices de matriz
function fromDisplayCoords(x: number, y: number): GoalCell {
  const col = ORIGIN_COL + x;
  const row = ORIGIN_ROW - y;
  return { row, col };
}

// helper: índices de matriz -> coords humanas (para el goal)
function rcToDisplayCoords(row: number, col: number): { x: number; y: number } {
  const x = col - ORIGIN_COL;
  const y = ORIGIN_ROW - row;
  return { x, y };
}

// parsea un comando tipo ".GOAL x y"
function parseGoalCommand(cmd: string): GoalCell | null {
  const trimmed = cmd.trim();
  if (!trimmed.toUpperCase().startsWith(".GOAL")) return null;

  const parts = trimmed.split(/\s+/);
  if (parts.length < 3) return null;

  const x = Number(parts[1]);
  const y = Number(parts[2]);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return null;

  const { row, col } = fromDisplayCoords(x, y);

  if (row < 0 || row >= GRID_ROWS || col < 0 || col >= GRID_COLS) {
    // fuera del grid, ignoramos
    return null;
  }

  return { row, col };
}

const Grid10x10: React.FC<GridProps> = ({
  matrixLine,
  onReset,
  goalCommand,
  onGoalClick,
  autoEnabled,
  onToggleAuto,
  autoPaused,
  onTogglePause,
}) => {
  const [grid, setGrid] = useState<Cell[][]>(() => createEmptyGrid());
  const [pose, setPose] = useState<RoverPose>(initialPose);
  const [goal, setGoal] = useState<GoalCell | null>(null);

  // ------- aplicar matriz completa --------
  const applyMatrix = useCallback((line: string) => {
    const parsed = parseMatrixLine(line);
    if (!parsed) return;

    const { grid: newGrid, pose: newPose } = parsed;

    setGrid(newGrid);

    // si la matriz trae un 2/3/4/5, actualizamos la pose
    if (newPose) {
      setPose(newPose);
    }
  }, []);

  // Si hay matrixLine, la aplicamos
  useEffect(() => {
    if (!matrixLine) return;
    applyMatrix(matrixLine);
  }, [matrixLine, applyMatrix]);

  // Si llega un comando .GOAL, actualizamos el objetivo
  useEffect(() => {
    if (!goalCommand) return;
    const parsedGoal = parseGoalCommand(goalCommand);
    if (!parsedGoal) return;
    setGoal(parsedGoal);
  }, [goalCommand]);

  const handleResetClick = () => {
    // 1) Resetear estado local del grid
    setPose(initialPose);
    setGrid(createEmptyGrid());
    setGoal(null);

    // 2) Avisar al padre para que mande el .CLEARALL al rover
    if (onReset) {
      onReset();
    }
  };

  // elegir la meta con un click en el grid
  const handleCellClick = (r: number, c: number) => {
    const cell = grid[r]?.[c];
    if (!cell) return;

    // ignorar obstáculos y la propia celda del rover
    if (cell.obstacle) return;
    if (pose.row === r && pose.col === c) return;

    const newGoal: GoalCell = { row: r, col: c };
    setGoal(newGoal);

    // Avisar al padre con el comando ".GOAL x y"
    if (onGoalClick) {
      const { x, y } = rcToDisplayCoords(r, c);
      const cmd = `.GOAL ${x} ${y}`;
      console.log("[Grid] send goal:", cmd); // debug
      onGoalClick(cmd);
    }
  };

  const columnCount = grid[0]?.length ?? GRID_COLS;
  const { x, y } = toDisplayCoords(pose);

  /* ===================== Camino A* ===================== */
  const pathPoints = useMemo(() => {
    if (!goal) return [];
    if (!grid || grid.length === 0) return [];
    return runAStarGrid(grid, { row: pose.row, col: pose.col }, goal);
  }, [grid, pose.row, pose.col, goal]);

  const pathSet = useMemo(() => {
    const s = new Set<string>();
    for (const p of pathPoints) {
      s.add(`${p.row},${p.col}`);
    }
    return s;
  }, [pathPoints]);

  // el botón de pausa solo está activo si AUTO está encendido y tenemos callback
  const pauseDisabled = !onTogglePause || !autoEnabled;

  // handler del botón AUTO (.AUTO / .STOPAUTO)
  const handleAutoClick = () => {
    if (!onToggleAuto) return;
    const cmd = autoEnabled ? ".STOPAUTO" : ".AUTO";
    console.log("[Grid] toggle auto:", cmd); // debug
    onToggleAuto(cmd);
  };

  // handler del botón PAUSE (.PAUSE / .RESUME)
  const handlePauseClick = () => {
    if (pauseDisabled || !onTogglePause) return;
    const cmd = autoPaused ? ".RESUME" : ".PAUSE";
    console.log("[Grid] toggle pause:", cmd); // debug
    onTogglePause(cmd);
  };

  return (
    <div
      style={{
        width: "100%",
        maxWidth: 400,
        margin: "0 auto",
        display: "flex",
        flexDirection: "column",
        gap: 8,
      }}
    >
      {/* mini header del grid */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          fontSize: 12,
          color: "#9ca3af",
          alignItems: "center",
        }}
      >
        <span>
          Position: ({x}, {y}) · Heading: {pose.dir}
        </span>

        <div
          style={{
            display: "flex",
            gap: 6,
          }}
        >
          {/* Botón AUTO / STOPAUTO */}
          <button
            onClick={handleAutoClick}
            disabled={!onToggleAuto}
            style={{
              fontSize: 11,
              padding: "2px 8px",
              borderRadius: 999,
              border: "1px solid #4b5563",
              background: autoEnabled ? "#16a34a" : "transparent",
              color: autoEnabled ? "#f9fafb" : "#e5e7eb",
              cursor: onToggleAuto ? "pointer" : "default",
            }}
          >
            {autoEnabled ? "Stop auto" : "Start auto"}
          </button>

          {/* Botón .PAUSE / .RESUME (solo activo cuando AUTO está ON) */}
          <button
            onClick={handlePauseClick}
            disabled={pauseDisabled}
            style={{
              fontSize: 11,
              padding: "2px 8px",
              borderRadius: 999,
              border: "1px solid #f59e0b",
              background: autoPaused ? "#f59e0b" : "transparent",
              color: autoPaused ? "#111827" : "#f59e0b",
              cursor: pauseDisabled ? "default" : "pointer",
              opacity: pauseDisabled ? 0.4 : 1,
            }}
          >
            {autoPaused ? "Resume" : "Pause"}
          </button>

          {/* Botón Reset */}
          <button
            onClick={handleResetClick}
            style={{
              fontSize: 11,
              padding: "2px 8px",
              borderRadius: 999,
              border: "1px solid #4b5563",
              background: "transparent",
              color: "#e5e7eb",
              cursor: "pointer",
            }}
          >
            Reset
          </button>
        </div>
      </div>

      {/* Grid visual 10x10 */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: `repeat(${columnCount}, minmax(0, 1fr))`,
          gap: 2,
          width: "100%",
        }}
      >
        {grid.map((rowCells, r) =>
          rowCells.map((cell, c) => {
            const isRover = pose.row === r && pose.col === c;
            const isGoal = goal != null && goal.row === r && goal.col === c;
            const isPath = pathSet.has(`${r},${c}`);

            let bg = baseGradient;
            let cellContent: React.ReactNode = "";
            let textColor = "#e5e7eb";
            let fontSizeValue = 11;

            if (isPath) {
              bg = "#0f766e"; // camino A*
            }

            if (cell.obstacle) {
              bg = "#b91c1c"; // obstáculo
              textColor = "#f9fafb";
            }

            if (isGoal) {
              bg = "#111827";
              cellContent = "🏁";
              textColor = "#f9fafb";
              fontSizeValue = 30;
            }

            if (isRover) {
              bg = "#eab308";
              cellContent = pose.dir;
              textColor = "#020617";
              fontSizeValue = 18;
            }

            return (
              <div
                key={`${r}-${c}`}
                onClick={() => handleCellClick(r, c)}
                style={{
                  aspectRatio: "1 / 1",
                  borderRadius: 4,
                  border: "1px solid #111827",
                  background: bg,
                  boxShadow: "0 0 0 1px rgba(15,23,42,0.6)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: fontSizeValue,
                  fontWeight: 600,
                  color: textColor,
                  cursor: cell.obstacle || isRover ? "default" : "pointer",
                }}
              >
                {cellContent}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default Grid10x10;
