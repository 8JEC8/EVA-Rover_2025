// src/components/VisualColumn.tsx
import React, {
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";
import WasdControls from "./WasdControls";
import WebotsView from "./WebotsView";
import CameraPanel from "./CameraPanel";
import type { WebSocketStatus } from "../types";

const WS_URL = import.meta.env.VITE_WS_URL ?? "ws://localhost:8000/ws";

type VisualColumnProps = {
  /** data URL tipo `data:image/jpeg;base64,...` (desde App/useWebSocketFeed) */
  imageDataUrl?: string;
  /** variantes de la misma imagen (sin procesar, colores, modelo) */
  imageVariants?: {
    raw?: string;
    colors?: string;
    yolo?: string;
  };
  /** callback opcional para loggear cada comando que se envía */
  onCommandSent?: (cmd: string) => void;
};

const VisualColumn: React.FC<VisualColumnProps> = ({
  imageDataUrl,
  imageVariants,
  onCommandSent,
}) => {
  const [wsStatus, setWsStatus] = useState<WebSocketStatus>("connecting");
  const wsRef = useRef<WebSocket | null>(null);

  const [consoleInput, setConsoleInput] = useState("");

  // =========================
  // Enviar comandos por WS (centralizado)
  // =========================
  const sendCommand = useCallback(
    (msg: any) => {
      const ws = wsRef.current;
      if (!ws || ws.readyState !== WebSocket.OPEN) return;

      try {
        ws.send(JSON.stringify(msg));
      } catch (err) {
        console.error("WS send error", err);
      }

      // Logging opcional hacia arriba
      if (onCommandSent) {
        const pretty =
          typeof msg === "string"
            ? msg
            : msg?.type
            ? String(msg.type)
            : JSON.stringify(msg);
        onCommandSent(pretty);
      }
    },
    [onCommandSent]
  );

  // Monitor serial: enviar lo que escribes como serial_write_cmd
  const handleConsoleSend = useCallback(() => {
    const cmd = consoleInput.trim();
    if (!cmd) return;

    // Nuevo protocolo: usamos tipo "serial_write_cmd"
    sendCommand({ type: "serial_write_cmd", data: cmd });

    setConsoleInput("");
  }, [consoleInput, sendCommand]);

  // =========================
  // Conectar WebSocket local
  // =========================
  useEffect(() => {
    let alive = true;

    const connect = () => {
      try {
        const ws = new WebSocket(WS_URL);
        wsRef.current = ws;
        setWsStatus("connecting");

        ws.onopen = () => alive && setWsStatus("open");
        ws.onerror = () => alive && setWsStatus("error");
        ws.onclose = () => {
          if (!alive) return;
          setWsStatus("closed");
          // reconexión simple
          setTimeout(connect, 1000);
        };

        // Por ahora no necesitamos leer nada aquí:
        // los mensajes entrantes los maneja useWebSocketFeed en App.
        ws.onmessage = () => {};
      } catch (err) {
        console.error("WS connect error", err);
        if (alive) setWsStatus("error");
      }
    };

    connect();
    return () => {
      alive = false;
      try {
        wsRef.current?.close();
      } catch {
        /* ignore */
      }
      wsRef.current = null;
    };
  }, []);

  // Badge pequeño para el monitor serial
  const monitorBadge = () => {
    const text =
      wsStatus === "open" ? "WS: OPEN" : `WS: ${wsStatus.toUpperCase()}`;
    const color =
      wsStatus === "open"
        ? "#16a34a"
        : wsStatus === "connecting"
        ? "#f59e0b"
        : wsStatus === "error"
        ? "#ef4444"
        : "#9ca3af";

    return (
      <span
        style={{
          padding: "2px 8px",
          borderRadius: 8,
          fontSize: 12,
          border: "1px solid #4b5563",
          color,
        }}
      >
        {text}
      </span>
    );
  };

  return (
    <div className="flex flex-col gap-3 h-full w-full p-2">
      {/* 1) Control WASD */}
      <WasdControls wsStatus={wsStatus} sendCommand={sendCommand} />

      {/* 1.5) Monitor serial */}
      <div
        style={{
          border: "1px solid #1f2937",
          borderRadius: 12,
          background: "#0b1220",
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <div
          style={{
            padding: 8,
            borderBottom: "1px solid #1f2937",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <strong>Serial Monitor</strong>
          {monitorBadge()}
        </div>
        <div
          style={{
            padding: 12,
            display: "flex",
            gap: 8,
            alignItems: "center",
          }}
        >
          <input
            type="text"
            value={consoleInput}
            onChange={(e) => setConsoleInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                handleConsoleSend();
              }
            }}
            placeholder=".GOAL 0 3"
            style={{
              flex: 1,
              padding: "6px 10px",
              borderRadius: 8,
              border: "1px solid #334155",
              background: "#020617",
              color: "#e5e7eb",
              fontSize: 13,
              outline: "none",
            }}
          />
          <button
            onClick={handleConsoleSend}
            disabled={wsStatus !== "open"}
            style={{
              padding: "6px 10px",
              borderRadius: 8,
              border: "1px solid #334155",
              background: wsStatus === "open" ? "#111827" : "#020617",
              color: wsStatus === "open" ? "#e5e7eb" : "#6b7280",
              cursor: wsStatus === "open" ? "pointer" : "not-allowed",
              fontSize: 13,
              fontWeight: 600,
            }}
          >
            Send
          </button>
        </div>
        <div
          style={{
            padding: "0 12px 12px",
            fontSize: 12,
            color: "#9ca3af",
          }}
        >
        </div>
      </div>

      {/* 3) Cámara */}
      <CameraPanel
        wsStatus={wsStatus}
        imageDataUrl={imageDataUrl}
        imageVariants={imageVariants}
        sendCommand={sendCommand}
      />
    </div>
  );
};

export default VisualColumn;
