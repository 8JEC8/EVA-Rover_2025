// src/components/WasdControls.tsx
import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import type { WebSocketStatus } from "../types";

type WasdControlsProps = {
  wsStatus: WebSocketStatus;
  /**
   * Enviar comando al backend.
   * Ejemplo de uso en el padre:
   *   sendCommand({ type: "wasd_cmd", key: "w", duration_ms: 300 });
   */
  sendCommand: (msg: any) => void;
};

const cardStyle: React.CSSProperties = {
  border: "1px solid #1f2937",
  borderRadius: 12,
  background: "#0b1220",
  overflow: "hidden",
  display: "flex",
  flexDirection: "column",
};

const sectionHeader: React.CSSProperties = {
  padding: 8,
  borderBottom: "1px solid #1f2937",
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
};

const badgeBase: React.CSSProperties = {
  padding: "2px 8px",
  borderRadius: 8,
  fontSize: 12,
  border: "1px solid",
};

const padBtn: React.CSSProperties = {
  width: 72,
  height: 72,
  borderRadius: 16,
  background:
    "radial-gradient(120% 120% at 30% 25%, #1f2937 0%, #0f172a 55%, #0b1220 100%)",
  border: "1px solid #263142",
  color: "#e5e7eb",
  boxShadow: "0 6px 18px rgba(0,0,0,0.35), inset 0 0 8px rgba(255,255,255,0.03)",
  cursor: "pointer",
  userSelect: "none",
  fontWeight: 700,
  fontSize: 18,
};

const smallText: React.CSSProperties = {
  fontSize: 12,
  color: "#9ca3af",
};

const toggleBtnBase: React.CSSProperties = {
  padding: "4px 10px",
  borderRadius: 999,
  border: "1px solid #334155",
  background: "#020617",
  color: "#e5e7eb",
  fontSize: 11,
  cursor: "pointer",
  fontWeight: 600,
};

function WsBadge({ status }: { status: WebSocketStatus }) {
  const base = { ...badgeBase };
  if (status === "open") {
    return (
      <span style={{ ...base, borderColor: "#16a34a", color: "#16a34a" }}>
        WS: OPEN
      </span>
    );
  }
  if (status === "connecting") {
    return (
      <span style={{ ...base, borderColor: "#f59e0b", color: "#f59e0b" }}>
        WS: CONNECTING
      </span>
    );
  }
  if (status === "error") {
    return (
      <span style={{ ...base, borderColor: "#ef4444", color: "#ef4444" }}>
        WS: ERROR
      </span>
    );
  }
  return (
    <span style={{ ...base, borderColor: "#6b7280", color: "#6b7280" }}>
      WS: CLOSED
    </span>
  );
}

const WasdControls: React.FC<WasdControlsProps> = ({
  wsStatus,
  sendCommand,
}) => {
  const [keyboardEnabled, setKeyboardEnabled] = useState(true);
  const pressedRef = useRef<Set<string>>(new Set());

  const canSend = wsStatus === "open";

  // Enviar comando WASD al backend
  const handleWasd = useCallback(
    (key: "w" | "a" | "s" | "d" | " ", durationMs?: number) => {
      if (!canSend) return;
      sendCommand({
        type: "wasd_cmd", // backend: elif t == "wasd_cmd": ...
        key,
        duration_ms: durationMs,
      });
    },
    [canSend, sendCommand]
  );

  // Manejo de teclado WASD (opcional, según toggle)
  useEffect(() => {
    if (!keyboardEnabled) {
      // si lo apagas, limpiamos el estado de teclas presionadas
      pressedRef.current.clear();
      return;
    }

    const down = (e: KeyboardEvent) => {
      // No capturar si está escribiendo en un input/textarea/contentEditable
      const target = e.target as HTMLElement | null;
      if (target) {
        const tag = target.tagName;
        const isTyping =
          tag === "INPUT" || tag === "TEXTAREA" || target.isContentEditable;
        if (isTyping) return;
      }

      const k = e.key.toLowerCase();
      if (k === "w" || k === "a" || k === "s" || k === "d") {
        if (!pressedRef.current.has(k)) {
          pressedRef.current.add(k);
          e.preventDefault();
          e.stopPropagation();
          handleWasd(k as "w" | "a" | "s" | "d");
        }
      }
    };

    const up = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (pressedRef.current.has(k)) {
        pressedRef.current.delete(k);
      }
    };

    window.addEventListener("keydown", down, { passive: false });
    window.addEventListener("keyup", up, { passive: false });

    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      pressedRef.current.clear();
    };
  }, [keyboardEnabled, handleWasd]);

  const toggleLabel = useMemo(
    () => (keyboardEnabled ? "WASD keyboard: ON" : "WASD keyboard: OFF"),
    [keyboardEnabled]
  );

  return (
    <div style={cardStyle}>
      <div style={sectionHeader}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <strong>Control — WASD</strong>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <WsBadge status={wsStatus} />
          <button
            type="button"
            onClick={() => setKeyboardEnabled((prev) => !prev)}
            style={{
              ...toggleBtnBase,
              background: keyboardEnabled ? "#16a34a20" : "#020617",
              borderColor: keyboardEnabled ? "#16a34a" : "#334155",
              color: keyboardEnabled ? "#bbf7d0" : "#e5e7eb",
            }}
          >
            {toggleLabel}
          </button>
        </div>
      </div>

      {/* Pad visual */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "auto auto auto",
          placeItems: "center",
          gap: 14,
          padding: 16,
        }}
      >
        <div />
        <button
          type="button"
          style={padBtn}
          disabled={!canSend}
          onMouseDown={() => handleWasd("w")}
          onTouchStart={(e) => {
            e.preventDefault();
            handleWasd("w");
          }}
          aria-label="W"
          title="W / Forward"
        >
          W
        </button>
        <div />

        <button
          type="button"
          style={padBtn}
          disabled={!canSend}
          onMouseDown={() => handleWasd("a")}
          onTouchStart={(e) => {
            e.preventDefault();
            handleWasd("a");
          }}
          aria-label="A"
          title="A / Left"
        >
          A
        </button>

        <button
          type="button"
          style={{
            ...padBtn,
            width: 88,
            height: 88,
            borderRadius: 20,
            fontSize: 22,
            boxShadow:
              "0 10px 24px rgba(0,0,0,0.45), inset 0 0 10px rgba(255,255,255,0.04)",
            background:
              "radial-gradient(130% 130% at 35% 25%, #233146 0%, #111a2e 55%, #0b1220 100%)",
          }}
          disabled={!canSend}
          onMouseDown={() => handleWasd("s")}
          onTouchStart={(e) => {
            e.preventDefault();
            handleWasd("s");
          }}
          aria-label="S"
          title="S / Backward"
        >
          S
        </button>

        <button
          type="button"
          style={padBtn}
          disabled={!canSend}
          onMouseDown={() => handleWasd("d")}
          onTouchStart={(e) => {
            e.preventDefault();
            handleWasd("d");
          }}
          aria-label="D"
          title="D / Right"
        >
          D
        </button>
      </div>

      <div style={{ padding: "0 16px 12px", ...smallText }}>
        {keyboardEnabled ? (
          <>
            Keyboard control also works: <b>W-A-S-D</b>.
          </>
        ) : (
          <>Keyboard control is disabled. Buttons only.</>
        )}
      </div>
    </div>
  );
};

export default WasdControls;
