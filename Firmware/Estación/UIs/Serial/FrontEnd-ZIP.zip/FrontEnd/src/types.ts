// ============================================================================
// Generic telemetry used in the frontend (before typing per sensor)
// ============================================================================

/**
 * Raw telemetry row in the frontend.
 * We use a single canonical timestamp: `ts`.
 */
export type TelemetryRow = {
  ts: string | number;
  [key: string]: number | string | boolean | null | undefined;
};

/**
 * Telemetry record already processed in the frontend
 * (with normalized timestamp and a sequence counter for stable keys).
 */
export type TelemetryRecord = {
  ts: string; // ISO
  data: Record<string, string | number | boolean | null>;
  seq: number;
};

// ============================================================================
// Image: variants for carousel / selector (original, colors, YOLO)
// ============================================================================

export type ImageVariants = {
  /** data URL of the original image (no processing) */
  raw?: string;
  /** data URL with multi-color detection */
  colors?: string;
  /** data URL with YOLO model detection */
  yolo?: string;
  /** MIME type (for example image/jpeg) */
  mime?: string;
  /** timestamp sent by the backend (ISO) */
  ts?: string;
  /** frame sequence number */
  seq?: number;
};

// ============================================================================
// Window options for charts
// ============================================================================

export type ChartWindowOptions = {
  /** Time window to display (seconds). Default: 10 */
  windowSec?: number;
};

// If somewhere you import KeyAliases (ChartsColumn, etc.)
export type KeyAliases = Record<string, string>;

// ============================================================================
// WebSocket status (for headers / hooks)
// ============================================================================

export type WebSocketStatus =
  | "idle"
  | "connecting"
  | "open"
  | "closed"
  | "error";

// ============================================================================
// Payloads coming from the backend (Pydantic → JSON)
// ============================================================================

/**
 * Matches TelemetryRover from the backend.
 */
export type TelemetryPayload = {
  timestamp: number;
  rssi: number;
  avg_rssi: number;
  temp1: number;
  hum1: number;
  temp2: number;
  hum2: number;
  v_esp: number;
  i_esp: number;
  p_esp: number;
  v_m1: number;
  i_m1: number;
  p_m1: number;
  v_m2: number;
  i_m2: number;
  p_m2: number;
  acc_x: number;
  acc_y: number;
  acc_z: number;
  gyro_x: number;
  gyro_y: number;
  gyro_z: number;
  dist1: number;
  dist2: number;
  dist3: number;
};

/**
 * Flexible image payload:
 * - New format (ImageFrame from the backend):
 *     timestamp, data_url, data_url_colors, data_url_model, raw_len
 * - Legacy fields (ts, seq, raw_b64, colors_b64, yolo_b64, b64, mime, ...),
 *   in case something old remains in the backend or during tests.
 */
export type ImagePayload = {
  // 🔹 New format (ImageFrame Pydantic)
  timestamp?: number;          // epoch seconds (float), same as TelemetryRover
  data_url?: string;           // original image (data:<mime>;base64,...)
  data_url_colors?: string;    // "colors" variant
  data_url_model?: string;     // "model" variant
  raw_len?: number;            // original base64 length (debug / stats)

  // 🔹 Old / alternative fields (for compatibility)
  ts?: string;                 // ISO timestamp (we previously sent it like this)
  seq?: number;
  mime?: string;
  content_type?: string;
  b64?: string;
  raw_b64?: string;
  colors_b64?: string;
  yolo_b64?: string;

  // 🔹 Any extra field the backend might send
  [key: string]: any;
};

// ============================================================================
// INBOUND messages from backend via WebSocket
// ============================================================================

export type SerialInEvent = {
  type: "serial_in";
  line: string;
  ts: number;
};

export type SerialOutEvent = {
  type: "serial_out";
  line: string;
  ts: number;
};

export type SerialStatusEvent =
  | {
      type: "serial_status";
      event: "opened";
      port: string;
      baud: number;
      ts: number;
    }
  | {
      type: "serial_status";
      event: "disconnected";
      ts: number;
    };

export type TelemetryEvent = {
  type: "telemetry";
  data: TelemetryPayload;
};

export type ImageEvent = {
  type: "image";
  data: ImagePayload;
};

/**
 * Any message the backend can send to the frontend via /ws.
 */
export type WsIncomingMessage =
  | TelemetryEvent
  | ImageEvent
  | SerialInEvent
  | SerialOutEvent
  | SerialStatusEvent;

// ============================================================================
// OUTBOUND messages to backend via WebSocket ( *_cmd commands)
// ============================================================================

// Serial monitor: send raw text to the port
export type SerialWriteCmd = {
  type: "serial_write_cmd";
  data?: string;
  line?: string; // backend accepts data or line, prioritizes line
};

// WASD controls (manual mode)
export type WasdCmd = {
  type: "wasd_cmd";
  key: "w" | "a" | "s" | "d" | " ";
  duration_ms?: number;
};

// LoRa / CSV / step configuration
export type ConfigCmd =
  | {
      type: "config_cmd";
      param: "chunk";
      bytes: number;
    }
  | {
      type: "config_cmd";
      param: "step";
      steps: number;
    }
  | {
      type: "config_cmd";
      param: "interval";
      interval_ms: number;
    }
  | {
      type: "config_cmd";
      param: "force";
      value: "SHORT" | "MID" | "LONG";
    };

// Telemetry and image control
export type TelemetryCmd =
  | {
      type: "telemetry_cmd";
      action: "start" | "go";
    }
  | {
      type: "telemetry_cmd";
      action: "stop";
    }
  | {
      type: "telemetry_cmd";
      action: "image" | "snapshot";
    }
  | {
      type: "telemetry_cmd";
      action: "cancel";
    };

// Autonomous mode
export type AutoCmd =
  | {
      type: "auto_cmd";
      action: "start" | "auto";
    }
  | {
      type: "auto_cmd";
      action: "stop" | "stopauto";
    }
  | {
      type: "auto_cmd";
      action: "pause";
    }
  | {
      type: "auto_cmd";
      action: "resume";
    };

// Map / goals / obstacles
export type MapCmd =
  | {
      type: "map_cmd";
      action: "goal";
      x: number;
      y: number;
    }
  | {
      type: "map_cmd";
      action: "obj";
      x: number;
      y: number;
    }
  | {
      type: "map_cmd";
      action: "reverse";
    }
  | {
      type: "map_cmd";
      action: "clear";
    }
  | {
      type: "map_cmd";
      action: "clearall";
    };

// System commands
export type SystemCmd = {
  type: "system_cmd";
  action: "reset";
};

/**
 * Any valid command the frontend can send to the backend via /ws.
 */
export type WsOutgoingMessage =
  | SerialWriteCmd
  | WasdCmd
  | ConfigCmd
  | TelemetryCmd
  | AutoCmd
  | MapCmd
  | SystemCmd;
