// src/lib/useWebSocketFeed.ts
import { useCallback, useEffect, useRef, useState } from "react";
import type {
  TelemetryRow,
  WebSocketStatus,
  TelemetryPayload,
  ImagePayload,
  WsIncomingMessage,
  ImageVariants,
} from "../types";

const WS_URL = import.meta.env.VITE_WS_URL ?? "ws://localhost:8000/ws";

type ConsoleLine = {
  ts: number; // ms
  text: string; // line shown in the serial monitor
};

type UseWebSocketFeedResult = {
  status: WebSocketStatus;
  isConnected: boolean;
  rows: TelemetryRow[];
  consoleLines: ConsoleLine[];
  /** Current main image (default one shown in the camera panel) */
  lastImageDataUrl: string | null;
  /** Image variants for the selector (raw / colors / yolo/model) */
  lastImageVariants: ImageVariants | null;
  /** Last RECV_ROVER_...,M,... line for the grid */
  lastMatrixLine: string | null;
  reconnect: () => void;
  /** Enviar una línea al monitor serial (va al backend como serial_write_cmd) */
  sendConsoleLine: (text: string) => void;
};

// ------------------------------------------------------------------
// Helper: parse a "RECV_ROVER_..." line into a TelemetryRow
// ------------------------------------------------------------------
function parseTelemetryLine(text: string): TelemetryRow | null {
  if (!text.startsWith("RECV_ROVER_")) return null;

  const payload = text.slice("RECV_ROVER_".length).trim();
  const parts = payload.split(",");

  if (parts.length < 2) return null;

  const nums: number[] = [];
  for (const p of parts) {
    const n = Number(p);
    if (!Number.isFinite(n)) {
      return null;
    }
    nums.push(n);
  }

  const ts = Date.now();
  const row: TelemetryRow = { ts } as TelemetryRow;

  // Order:
  // 0: rssi
  // 1: avg_rssi
  // 2: temp1
  // 3: hum1
  // 4: temp2
  // 5: hum2
  // 6: v_esp
  // 7: i_esp
  // 8: p_esp
  // 9: v_m1
  // 10: i_m1
  // 11: p_m1
  // 12: v_m2
  // 13: i_m2
  // 14: p_m2
  // 15: gyro_x
  // 16: gyro_y
  // 17: gyro_z
  // 18: acc_x
  // 19: acc_y
  // 20: acc_z
  // 21: dist1
  // 22: dist2
  // 23: dist3

  if (nums.length >= 1) (row as any).rssi = nums[0];
  if (nums.length >= 2) (row as any).avg_rssi = nums[1];
  if (nums.length >= 3) (row as any).temp1 = nums[2];
  if (nums.length >= 4) (row as any).hum1 = nums[3];
  if (nums.length >= 5) (row as any).temp2 = nums[4];
  if (nums.length >= 6) (row as any).hum2 = nums[5];
  if (nums.length >= 7) (row as any).v_esp = nums[6];
  if (nums.length >= 8) (row as any).i_esp = nums[7];
  if (nums.length >= 9) (row as any).p_esp = nums[8];
  if (nums.length >= 10) (row as any).v_m1 = nums[9];
  if (nums.length >= 11) (row as any).i_m1 = nums[10];
  if (nums.length >= 12) (row as any).p_m1 = nums[11];
  if (nums.length >= 13) (row as any).v_m2 = nums[12];
  if (nums.length >= 14) (row as any).i_m2 = nums[13];
  if (nums.length >= 15) (row as any).p_m2 = nums[14];
  if (nums.length >= 16) (row as any).gyro_x = nums[15];
  if (nums.length >= 17) (row as any).gyro_y = nums[16];
  if (nums.length >= 18) (row as any).gyro_z = nums[17];
  if (nums.length >= 19) (row as any).acc_x = nums[18];
  if (nums.length >= 20) (row as any).acc_y = nums[19];
  if (nums.length >= 21) (row as any).acc_z = nums[20];
  if (nums.length >= 22) (row as any).dist1 = nums[21];
  if (nums.length >= 23) (row as any).dist2 = nums[22];
  if (nums.length >= 24) (row as any).dist3 = nums[23];

  (row as any).raw_line = payload;

  return row;
}

export function useWebSocketFeed(
  maxRows: number = 900
): UseWebSocketFeedResult {
  const [status, setStatus] = useState<WebSocketStatus>("connecting");
  const [rows, setRows] = useState<TelemetryRow[]>([]);
  const [consoleLines, setConsoleLines] = useState<ConsoleLine[]>([]);
  const [lastImageDataUrl, setLastImageDataUrl] = useState<string | null>(null);
  const [lastImageVariants, setLastImageVariants] =
    useState<ImageVariants | null>(null);
  const [lastMatrixLine, setLastMatrixLine] = useState<string | null>(null);

  const socketRef = useRef<WebSocket | null>(null);

  const isConnected = status === "open";

  // ========================================================================
  // Main handler for incoming WebSocket messages
  // ========================================================================
  const handleMessage = useCallback(
    (event: MessageEvent<string>) => {
      let msg: WsIncomingMessage | any;
      try {
        msg = JSON.parse(event.data);
      } catch (err) {
        console.error("WS message parse error", err);
        return;
      }

      if (!msg || typeof msg.type !== "string") return;

      // ----------------- STRUCTURED TELEMETRY (JSON) -----------------
      if (msg.type === "telemetry") {
        const payload = msg.data as TelemetryPayload | undefined;
        if (!payload || typeof payload.timestamp !== "number") return;

        const { timestamp, ...rest } = payload;

        const row: TelemetryRow = {
          ts: timestamp * 1000, // backend sends seconds
          ...(rest as any),
        };

        setRows((prev) => {
          const next = [...prev, row];
          if (next.length > maxRows) {
            next.splice(0, next.length - maxRows);
          }
          return next;
        });

        return;
      }

      // ----------------- STRUCTURED IMAGE (JSON) -----------------
      if (msg.type === "image" || msg.type === "image_frame") {
        const payload = (msg.data ??
          (msg as any).frame ??
          (msg as any).payload ??
          msg) as ImagePayload;

        const mime = payload.mime ?? payload.content_type ?? "image/jpeg";

        const toDataUrl = (b64?: string | null): string | undefined => {
          if (!b64 || typeof b64 !== "string" || b64.length === 0) return;
          return `data:${mime};base64,${b64}`;
        };

        // NEW FORMAT
        const rawFromNew = payload.data_url;
        const colorsFromNew = payload.data_url_colors;
        const modelFromNew = payload.data_url_model;

        // LEGACY
        const rawFromOld = toDataUrl(payload.raw_b64);
        const colorsFromOld = toDataUrl(payload.colors_b64);
        const yoloFromOld = toDataUrl(payload.yolo_b64);
        const aliasFromOld = toDataUrl(payload.b64);

        const raw = rawFromNew || rawFromOld || aliasFromOld;
        const colors = colorsFromNew || colorsFromOld;
        const yolo = modelFromNew || yoloFromOld;

        let tsIso: string | undefined = payload.ts;
        if (!tsIso && typeof payload.timestamp === "number") {
          tsIso = new Date(payload.timestamp * 1000).toISOString();
        }

        const variants: ImageVariants = {
          raw,
          colors,
          yolo,
          mime,
          ts: tsIso,
          seq: payload.seq,
        };

        setLastImageVariants(variants);

        let primary: string | null = null;

        if (colors) {
          primary = colors;
        } else if (yolo) {
          primary = yolo;
        } else if (raw) {
          primary = raw;
        }

        if (primary) {
          setLastImageDataUrl(primary);
        } else if (payload.data_url) {
          setLastImageDataUrl(payload.data_url);
        } else {
          console.warn("WS image message without usable data:", msg);
        }

        return;
      }

      // ----------------- SERIAL CONSOLE: INBOUND -----------------
      if (msg.type === "serial_in") {
        const tsSec =
          typeof msg.ts === "number" ? msg.ts : Date.now() / 1000.0;
        const tsMs = tsSec * 1000;

        const text =
          typeof msg.line === "string"
            ? msg.line
            : msg.line != null
            ? String(msg.line)
            : "";

        setConsoleLines((prev) => {
          const next = [...prev, { ts: tsMs, text }];
          if (next.length > 2000) {
            next.splice(0, next.length - 2000);
          }
          return next;
        });

        if (text.startsWith("RECV_ROVER_") && text.includes(",M,")) {
          setLastMatrixLine(text);
        }

        const telemetryRow = parseTelemetryLine(text);
        if (telemetryRow) {
          setRows((prev) => {
            const next = [...prev, telemetryRow];
            if (next.length > maxRows) {
              next.splice(0, next.length - maxRows);
            }
            return next;
          });
        }

        return;
      }

      // ----------------- SERIAL CONSOLE: OUTBOUND ECHO -----------------
      if (msg.type === "serial_out") {
        const tsSec =
          typeof msg.ts === "number" ? msg.ts : Date.now() / 1000.0;
        const tsMs = tsSec * 1000;

        const text =
          typeof msg.line === "string"
            ? msg.line
            : msg.line != null
            ? String(msg.line)
            : "";

        setConsoleLines((prev) => {
          const next = [...prev, { ts: tsMs, text }];
          if (next.length > 2000) {
            next.splice(0, next.length - 2000);
          }
          return next;
        });

        return;
      }

      // ----------------- SERIAL STATUS EVENTS -----------------
      if (msg.type === "serial_status") {
        const tsSec =
          typeof msg.ts === "number" ? msg.ts : Date.now() / 1000.0;
        const tsMs = tsSec * 1000;

        let text = "";
        if (msg.event === "opened") {
          const port = typeof msg.port === "string" ? msg.port : "?";
          const baud =
            typeof msg.baud === "number" ? msg.baud : (msg.baud ?? "?");
          text = `[serial] opened (${port} @ ${baud})`;
        } else if (msg.event === "disconnected") {
          text = "[serial] disconnected";
        } else if (msg.event === "write_error") {
          text = `[serial] write_error: ${msg.reason ?? "unknown"} - ${
            msg.line ?? ""
          }`;
        }

        if (text) {
          setConsoleLines((prev) => {
            const next = [...prev, { ts: tsMs, text }];
            if (next.length > 2000) {
              next.splice(0, next.length - 2000);
            }
            return next;
          });
        }

        return;
      }

      // Other unknown types are ignored for now
    },
    [maxRows]
  );

  // ========================================================================
  // WebSocket connection and reconnection
  // ========================================================================
  const connect = useCallback(() => {
    if (
      socketRef.current &&
      (socketRef.current.readyState === WebSocket.OPEN ||
        socketRef.current.readyState === WebSocket.CONNECTING)
    ) {
      return;
    }

    const ws = new WebSocket(WS_URL);
    socketRef.current = ws;
    setStatus("connecting");

    ws.onopen = () => setStatus("open");
    ws.onclose = () => {
      setStatus("closed");
      socketRef.current = null;
    };
    ws.onerror = () => setStatus("error");
    ws.onmessage = handleMessage;
  }, [handleMessage]);

  useEffect(() => {
    connect();
    return () => {
      if (socketRef.current) {
        try {
          socketRef.current.close();
        } catch {
          // ignore
        }
      }
    };
  }, [connect]);

  const reconnect = useCallback(() => {
    if (socketRef.current) {
      try {
        socketRef.current.close();
      } catch {
        // ignore
      }
      socketRef.current = null;
    }
    connect();
  }, [connect]);

  // 🔹 Función para mandar comandos al monitor serial
  const sendConsoleLine = useCallback((text: string) => {
    const trimmed = text.trim();
    if (!trimmed) return;

    const ws = socketRef.current;
    if (!ws) {
      console.warn(
        "[WS] sendConsoleLine: socketRef.current es null. No se envía:",
        trimmed
      );
      return;
    }

    console.log(
      "[WS] sendConsoleLine ->",
      trimmed,
      "readyState=",
      ws.readyState
    );

    if (ws.readyState !== WebSocket.OPEN) {
      console.warn(
        "[WS] socket NO está OPEN, no se puede enviar:",
        trimmed
      );
      return;
    }

    ws.send(
      JSON.stringify({
        type: "serial_write_cmd", // tipo que el backend debe manejar
        line: trimmed, // acceso directo
        data: trimmed, // acceso alterno msg.data.line
      })
    );
  }, []);

  return {
    status,
    isConnected,
    rows,
    consoleLines,
    lastImageDataUrl,
    lastImageVariants,
    lastMatrixLine,
    reconnect,
    sendConsoleLine,
  };
}
