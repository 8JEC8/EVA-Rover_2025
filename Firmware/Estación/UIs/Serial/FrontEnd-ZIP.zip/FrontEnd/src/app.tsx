// src/App.tsx
import React, { useMemo, useState } from "react";
import HeaderStatus from "./components/HeaderStatus";
import SerialFooter from "./components/SerialFooter";
import PanelColumns from "./components/PanelColumns";
import Grid10x10 from "./components/Grid10x10";
import { useWebSocketFeed } from "./lib/useWebSocketFeed";

// Debe coincidir con el grid (lo dejamos por claridad aunque ya no se use aquí)
const GRID_ROWS = 10;

// Extrae el último comando .GOAL (x,y) visto en la consola
function extractLastGoalCommand(
  consoleLines: { ts: number; text: string }[]
): string | null {
  let last: string | null = null;

  for (const { text } of consoleLines) {
    const raw = text.trim();
    if (!raw) continue;

    // 1) Si tú mismo escribes ".GOAL 0 3" en el monitor:
    let m = raw.match(/\.GOAL\s+(-?\d+)\s+(-?\d+)/i);
    if (m) {
      last = `.GOAL ${m[1]} ${m[2]}`;
      continue;
    }

    // 2) Logs tipo SENT_EST_GOAL0,3, ACK_GOAL0,3, GOAL_UPDATED0,3, GOAL_SET 0,3, etc.
    m = raw.match(/GOAL[^0-9-]*(-?\d+)\s*,\s*(-?\d+)/i);
    if (m) {
      last = `.GOAL ${m[1]} ${m[2]}`; // lo canonizamos para que el grid lo entienda
    }
  }

  return last;
}

export default function App() {
  const {
    status,
    rows,
    consoleLines,
    lastImageDataUrl,
    lastImageVariants,
    lastMatrixLine,
    reconnect,
    // función para mandar texto al monitor serial vía WS
    sendConsoleLine,
  } = useWebSocketFeed(900);

  const [showGrid, setShowGrid] = useState(false);
  const [autoEnabled, setAutoEnabled] = useState(false);
  const [autoPaused, setAutoPaused] = useState(false);

  // .GO / .STOP de telemetría
  const [telemetryEnabled, setTelemetryEnabled] = useState(false);

  const consoleTextLines = useMemo(
    () => consoleLines.map((item) => item.text),
    [consoleLines]
  );

  const lastGoalCommand = useMemo(
    () => extractLastGoalCommand(consoleLines),
    [consoleLines]
  );

  // ===================== handlers que hablan con el backend =====================

  const handleGridClear = () => {
    console.log("[App] send:", ".CLEARALL");
    sendConsoleLine(".CLEARALL");
  };

  // Grid10x10 ya nos pasa el comando completo ".GOAL x y"
  const handleGridGoalClick = (cmd: string) => {
    console.log("[App] send goal:", cmd);
    sendConsoleLine(cmd);
  };

  // .AUTO / .STOPAUTO -> recibe el comando desde Grid10x10
  const handleToggleAuto = (cmd: string) => {
    console.log("[App] toggle auto, send:", cmd);
    sendConsoleLine(cmd);

    if (cmd === ".AUTO") {
      setAutoEnabled(true);
    } else if (cmd === ".STOPAUTO") {
      setAutoEnabled(false);
      setAutoPaused(false); // apagando AUTO, quitamos pausa
    }
  };

  // .PAUSE / .RESUME -> recibe comando desde Grid10x10
  const handleTogglePause = (cmd: string) => {
    if (!autoEnabled) return; // seguridad

    console.log("[App] toggle pause, send:", cmd);
    sendConsoleLine(cmd);

    if (cmd === ".PAUSE") {
      setAutoPaused(true);
    } else if (cmd === ".RESUME") {
      setAutoPaused(false);
    }
  };

  // .GO / .STOP para telemetría (se mandan como comandos seriales también)
  const handleToggleTelemetry = () => {
    setTelemetryEnabled((prev) => {
      const next = !prev;
      const cmd = next ? ".GO" : ".STOP";
      console.log("[App] toggle telemetry, send:", cmd);
      sendConsoleLine(cmd);
      return next;
    });
  };

  // ============================================================================

  return (
    <div
      style={{
        minHeight: "100dvh",
        background: "#0a0f1a",
        color: "#e5e7eb",
      }}
    >
      <HeaderStatus
        status={status}
        onReconnect={reconnect}
        showGrid={showGrid}
        onToggleGrid={() => setShowGrid((prev) => !prev)}
      />

      {showGrid && (
        <div
          style={{
            maxWidth: 1400,
            margin: "0 auto",
            padding: "8px 12px 0",
          }}
        >
          <div
            style={{
              borderRadius: 12,
              border: "1px solid #1f2937",
              padding: "10px 12px 14px",
              background: "rgba(15,23,42,0.9)",
            }}
          >
            <div
              style={{
                fontSize: 14,
                marginBottom: 8,
                color: "#9ca3af",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <span>Grid 10×10</span>
            </div>

            <Grid10x10
              matrixLine={lastMatrixLine}
              onReset={handleGridClear}
              goalCommand={lastGoalCommand}
              onGoalClick={handleGridGoalClick} // recibe ".GOAL x y"
              autoEnabled={autoEnabled}
              onToggleAuto={handleToggleAuto} // recibe ".AUTO" / ".STOPAUTO"
              autoPaused={autoPaused}
              onTogglePause={handleTogglePause} // recibe ".PAUSE" / ".RESUME"
            />
          </div>
        </div>
      )}

      <main
        style={{
          maxWidth: 1400,
          margin: "0 auto",
          padding: "12px",
          paddingBottom: 220,
          minHeight: 0,
        }}
      >
        <PanelColumns
          rows={rows}
          wsStatus={status}
          imageDataUrl={lastImageDataUrl ?? undefined}
          imageVariants={lastImageVariants ?? undefined}
          telemetryEnabled={telemetryEnabled}
          onToggleTelemetry={handleToggleTelemetry}
        />
      </main>

      <SerialFooter lines={consoleTextLines} />
    </div>
  );
}
