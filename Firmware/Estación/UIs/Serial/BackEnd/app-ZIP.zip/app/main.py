# app/main.py
import asyncio
import json
from typing import Any, Dict

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

from .core.config import settings
from .core.ws import WSManager
from .models import (
    TelemetryRover,
    ImageFrame,
)
from .routers import api as api_router
from .services.serial_service import SerialWorker  # asegúrate que el archivo sea serial_service.py

app = FastAPI(title="Backend Rover Serial", version="1.0.0")

# ---------- CORS ----------
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_allow_origins,
    allow_methods=["*"],
    allow_headers=["*"],
    allow_credentials=True,
)

ws_manager = WSManager()
serial_worker: SerialWorker | None = None

# Log rápido de configuración al importar el módulo
print(
    f"[Settings] serial_enabled={settings.serial_enabled} "
    f"port={settings.serial_port!r} baud={settings.serial_baud} "
    f"timeout={settings.serial_timeout_s}"
)

# ---------------- WebSocket ----------------
@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    """
    WebSocket principal:
    - Recibe comandos desde el frontend:
      * serial_write_cmd: enviar texto crudo al puerto (monitor serial).
      * wasd_cmd: controles de movimiento (W/A/S/D).
      * config_cmd: configuración de chunks, steps, intervalos y potencia LoRa.
      * telemetry_cmd: control de envío de telemetría e imagen (.GO, .STOP, .IMAGE, .CANCEL).
      * auto_cmd: control del modo autónomo.
      * map_cmd: objetivos, obstáculos y limpieza del mapa.
      * system_cmd: comandos generales del rover (reset).
    - Los datos (telemetría numérica, imagen, consola) se envían desde el SerialWorker
      vía ws_manager.broadcast_json() con otros tipos:
      * telemetry, image, serial_in, serial_out, serial_status, etc.
    """
    await ws_manager.connect(ws)
    try:
        while True:
            # Recibir comandos entrantes del cliente
            text = await ws.receive_text()
            try:
                data = json.loads(text)
            except Exception:
                # Ignora mensajes no-JSON
                continue

            t = data.get("type")

            # 1) Monitor serial (vía WS): enviar texto al puerto
            if t == "serial_write_cmd":
                # Acepta tanto "data" como "line" por compatibilidad
                msg = str(data.get("data") or data.get("line") or "").strip()
                if serial_worker and msg:
                    try:
                        # Enviar texto tal cual al puerto serial
                        serial_worker.send_line(msg, append_nl=True)
                    except Exception as e:
                        print("[WS] Error en serial_write_cmd:", e)
                        # No tiramos la conexión por errores del serial

            # 2) Controles WASD (compacto)
            elif t == "wasd_cmd":
                key = str(data.get("key", "")).lower()
                duration = data.get("duration_ms", None)
                if serial_worker and key:
                    try:
                        # send_wasd internamente mapea:
                        # 'w' -> "W"  Movimiento Hacia Adelante
                        # 's' -> "S"  Movimiento Hacia Atrás
                        # 'a' -> "A"  Movimiento CCW (giro antihorario)
                        # 'd' -> "D"  Movimiento CW (giro horario)
                        serial_worker.send_wasd(key, duration_ms=duration)
                    except Exception as e:
                        print("[WS] Error en wasd_cmd:", e)

            # 3) Configuración LoRa / CSV / pasos
            elif t == "config_cmd":
                # param puede ser: "chunk", "step", "interval", "force"
                param = str(data.get("param") or data.get("name") or "").lower()
                if not (serial_worker and param):
                    continue
                try:
                    if param == "chunk":
                        size_bytes = int(data.get("bytes", 0))
                        if size_bytes > 0:
                            serial_worker.send_line(f".CHUNK{size_bytes}", append_nl=True)
                            # .CHUNKxx  -> Elegir tamaño de Chunks (Bytes)

                    elif param == "step":
                        steps = int(data.get("steps", 0))
                        if steps > 0:
                            serial_worker.send_line(f".STEP{steps}", append_nl=True)
                            # .STEPxx   -> Elegir cantidad de Steps (1/32: 6400/Vuelta)

                    elif param == "interval":
                        interval_ms = int(data.get("interval_ms", 0))
                        if interval_ms > 0:
                            serial_worker.send_line(f".INTERVAL{interval_ms}", append_nl=True)
                            # .INTERVAL -> Elegir intervalo de CSV en milisegundos

                    elif param == "force":
                        force_val = str(data.get("value", "")).upper()
                        if force_val:
                            serial_worker.send_line(f".FORCE{force_val}", append_nl=True)
                            # .FORCESHORT / .FORCEMID / .FORCELONG -> Cambiar configuración LoRa

                except Exception as e:
                    print("[WS] Error en config_cmd:", e)

            # 4) Control de envío de telemetría e imagen
            elif t == "telemetry_cmd":
                # action puede ser: "start", "stop", "image", "cancel"
                action = str(data.get("action") or data.get("cmd") or "").lower()
                if not (serial_worker and action):
                    continue
                try:
                    if action in ("start", "go"):
                        serial_worker.send_line(".GO", append_nl=True)
                        # .GO / .START -> Inicia envío de telemetría

                    elif action == "stop":
                        serial_worker.send_line(".STOP", append_nl=True)
                        # .STOP        -> Detiene envío de telemetría

                    elif action in ("image", "snapshot"):
                        serial_worker.send_line(".IMAGE", append_nl=True)
                        # .IMAGE       -> Capturar y recibir Imagen

                    elif action == "cancel":
                        serial_worker.send_line(".CANCEL", append_nl=True)
                        # .CANCEL      -> Detener envío de Imagen

                except Exception as e:
                    print("[WS] Error en telemetry_cmd:", e)

            # 5) Control del modo autónomo
            elif t == "auto_cmd":
                # action puede ser: "start", "stop", "pause", "resume"
                action = str(data.get("action") or data.get("cmd") or "").lower()
                if not (serial_worker and action):
                    continue
                try:
                    if action in ("start", "auto"):
                        serial_worker.send_line(".AUTO", append_nl=True)
                        # .AUTO      -> Inicia modo autónomo

                    elif action in ("stop", "stopauto"):
                        serial_worker.send_line(".STOPAUTO", append_nl=True)
                        # .STOPAUTO  -> Detiene modo autónomo

                    elif action == "pause":
                        serial_worker.send_line(".PAUSE", append_nl=True)
                        # .PAUSE     -> Pausa modo autónomo

                    elif action == "resume":
                        serial_worker.send_line(".RESUME", append_nl=True)
                        # .RESUME    -> Reanuda modo autónomo

                except Exception as e:
                    print("[WS] Error en auto_cmd:", e)

            # 6) Objetivos, obstáculos y mapa
            elif t == "map_cmd":
                # action puede ser: "goal", "obj", "reverse", "clear", "clearall"
                action = str(data.get("action") or data.get("cmd") or "").lower()
                if not (serial_worker and action):
                    continue
                try:
                    if action == "goal":
                        x = int(data.get("x", 0))
                        y = int(data.get("y", 0))
                        serial_worker.send_line(f".GOAL {x} {y}", append_nl=True)
                        # .GOAL x y   -> Establece objetivo en coordenadas X,Y

                    elif action == "obj":
                        x = int(data.get("x", 0))
                        y = int(data.get("y", 0))
                        serial_worker.send_line(f".OBJ {x} {y}", append_nl=True)
                        # .OBJ x y    -> Marca obstáculo en coordenadas X,Y

                    elif action == "reverse":
                        serial_worker.send_line(".REVERSE", append_nl=True)
                        # .REVERSE    -> Establece objetivo en (0,0) / regreso al origen (según firmware)

                    elif action == "clear":
                        serial_worker.send_line(".CLEAR", append_nl=True)
                        # .CLEAR      -> Limpia mapa manteniendo pose

                    elif action == "clearall":
                        serial_worker.send_line(".CLEARALL", append_nl=True)
                        # .CLEARALL   -> Limpia mapa y resetea pose

                except Exception as e:
                    print("[WS] Error en map_cmd:", e)

            # 7) Comandos de sistema generales
            elif t == "system_cmd":
                # action puede ser: "reset"
                action = str(data.get("action") or data.get("cmd") or "").lower()
                if not (serial_worker and action):
                    continue
                try:
                    if action == "reset":
                        serial_worker.send_line(".RESET", append_nl=True)
                        # .RESET      -> Resetear Rover – EVA

                except Exception as e:
                    print("[WS] Error en system_cmd:", e)

            # Aquí puedes agregar otros tipos si los necesitas

    except WebSocketDisconnect:
        ws_manager.disconnect(ws)
    except Exception as e:
        print("[WS] Error genérico en ws_endpoint:", e)
        ws_manager.disconnect(ws)


# --------- Helpers para emitir en WS (desde el hilo serial) ---------
async def emit_ws_telemetry(tm: TelemetryRover):
  """
  Enviar telemetría a todos los clientes WS.
  Formato:
    { type: "telemetry", data: { ...campos de TelemetryRover... } }
  que es justo lo que está esperando tu hook/useTelemetry en el frontend.
  """
  await ws_manager.broadcast_json(
      {
          "type": "telemetry",
          "data": tm.model_dump(),  # Pydantic v2
      }
  )


async def emit_ws_image(img: ImageFrame | Dict[str, Any]):
    """
    Enviar frame de imagen a todos los clientes WS.

    Soporta dos casos:
    - img es un ImageFrame (Pydantic)  -> usamos .model_dump()
    - img es un dict JSON-ready        -> lo mandamos tal cual

    El frontend lo consume como:
      msg.type === "image"
      msg.data.b64  (base64 del JPEG procesado)
    """
    # Normalizar a dict
    if hasattr(img, "model_dump"):
        data = img.model_dump()
    elif isinstance(img, dict):
        data = img
    else:
        data = {"raw": repr(img)}

    await ws_manager.broadcast_json(
        {
            "type": "image",  # el hook maneja "image" y "image_frame"
            "data": data,     # ej. { ts, seq, b64, mime? }
        }
    )


async def emit_ws_console(payload: dict):
    """
    Consola para el front:
    - serial_in:  líneas que llegan del puerto
    - serial_out: eco de lo que enviamos al puerto
    - serial_status: opened/disconnected, etc.

    El SerialWorker ya arma estos payloads con:
      { "type": "serial_in" | "serial_out" | "serial_status", ... }
    """
    await ws_manager.broadcast_json(payload)


# ---------------- Ciclo de vida ----------------
@app.on_event("startup")
async def startup():
    global serial_worker
    loop = asyncio.get_running_loop()

    if settings.serial_enabled:
        serial_worker = SerialWorker(
            loop=loop,
            emit_ws_telemetry=emit_ws_telemetry,
            emit_ws_image=emit_ws_image,
            emit_ws_console=emit_ws_console,  # consola WS
        )
        serial_worker.start()
        print("[App] SerialWorker iniciado.")
    else:
        print("[App] Serial deshabilitado por settings.")


@app.on_event("shutdown")
async def shutdown():
    global serial_worker
    if serial_worker:
        serial_worker.stop()
        serial_worker = None
    print("[App] Terminada.")


# --------- Router REST principal (/api/...) ---------
app.include_router(api_router.router, prefix="/api")
