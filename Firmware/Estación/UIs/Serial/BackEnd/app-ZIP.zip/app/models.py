# app/models.py
from typing import Any, Dict, Optional, List
from pydantic import BaseModel, Field


class TelemetryRover(BaseModel):
    """
    Telemetría normalizada del rover según el orden que indicaste.
    """
    timestamp: float = Field(..., description="Epoch seconds (float).")
    rssi: int
    avg_rssi: int
    temp1: float
    hum1: float
    temp2: float
    hum2: float
    v_esp: float
    i_esp: float
    p_esp: float
    v_m1: float
    i_m1: float
    p_m1: float
    v_m2: float
    i_m2: float
    p_m2: float
    acc_x: float
    acc_y: float
    acc_z: float
    gyro_x: float
    gyro_y: float
    gyro_z: float
    dist1: float
    dist2: float
    dist3: float


class ImageFrame(BaseModel):
    """
    Imagen recibida por serial en Base64.

    data_url          -> imagen "principal" (por compatibilidad; usamos la original)
    data_url_colors   -> versión procesada en modo "Colores"
    data_url_model    -> versión procesada en modo "Modelo"
    """
    timestamp: float = Field(..., description="Epoch seconds (float).")

    # Campo original que ya usábamos
    data_url: str = Field(..., description="data:<mime>;base64,<payload> (imagen original)")

    raw_len: int

    # Nuevos campos para las otras variantes
    data_url_colors: Optional[str] = Field(
        None,
        description="Imagen procesada para modo 'Colores' (data:<mime>;base64,<payload>)",
    )
    data_url_model: Optional[str] = Field(
        None,
        description="Imagen procesada para modo 'Modelo' (data:<mime>;base64,<payload>)",
    )


class HealthResponse(BaseModel):
    status: str
