# app/routers/api.py
from fastapi import APIRouter
from ..models import HealthResponse

router = APIRouter(tags=["api"])

@router.get("/health", response_model=HealthResponse)
async def health():
    return HealthResponse(status="ok")