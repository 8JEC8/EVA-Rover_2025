# app/services/rover_parser.py
from __future__ import annotations

import time
import os
from typing import Any, Dict, Optional

from ..models import ImageFrame

PREFIX = "RECV_ROVER_"

# Ruta absoluta a app/best.pt (donde tienes el modelo)
# __file__ -> ...\BackEnd\app\services\rover_parser.py
_SERVICES_DIR = os.path.dirname(__file__)
_APP_DIR = os.path.abspath(os.path.join(_SERVICES_DIR, ".."))
MODEL_BEST_PATH = os.path.join(_APP_DIR, "best.pt")

# Funciones del pipeline de visión (tu vision_pipeline.py)
from .vision_pipeline import (
    reconstruct_image_from_b64_line,
    multi_color_detection,
    model_detection,
    encode_image_to_b64,
)


def _parse_int_list_from_revc_rover(line: str) -> Optional[list[int]]:
    """
    Extrae los 24 enteros de una línea tipo:
    RECV_ROVER_-55,-54,2824,6071,2669,6034,487,3335,1626,1119,-6,10,...
    """
    line = line.strip()
    if not line.startswith(PREFIX):
        return None

    raw = line[len(PREFIX) :]
    parts = raw.split(",")
    if len(parts) != 24:
        # esperamos exactamente 24 valores
        return None

    try:
        nums = [int(p) for p in parts]
    except ValueError:
        return None

    return nums


def try_parse_telemetry(line: str) -> Optional[Dict[str, Any]]:
    """
    Intenta parsear una línea de serial en un payload de telemetría.
    """
    nums = _parse_int_list_from_revc_rover(line)
    if nums is None:
        return None

    (
        rssi,
        avg_rssi,
        temp1,
        hum1,
        temp2,
        hum2,
        v_esp,
        i_esp,
        p_esp,
        v_m1,
        i_m1,
        p_m1,
        v_m2,
        i_m2,
        p_m2,
        gyro_x,
        gyro_y,
        gyro_z,
        acc_x,
        acc_y,
        acc_z,
        dist1,
        dist2,
        dist3,
    ) = nums

    ts = time.time()  # segundos (float)

    payload: Dict[str, Any] = {
        "timestamp": ts,
        # Señal
        "rssi": rssi,
        "avg_rssi": avg_rssi,
        # Temp/Hum en *100
        "temp1": temp1,
        "hum1": hum1,
        "temp2": temp2,
        "hum2": hum2,
        # ESP (mV, mA, mW)
        "v_esp": v_esp,
        "i_esp": i_esp,
        "p_esp": p_esp,
        # Motores (mV, mA, mW)
        "v_m1": v_m1,
        "i_m1": i_m1,
        "p_m1": p_m1,
        "v_m2": v_m2,
        "i_m2": i_m2,
        "p_m2": p_m2,
        # IMU
        "gyro_x": gyro_x,
        "gyro_y": gyro_y,
        "gyro_z": gyro_z,
        "acc_x": acc_x,
        "acc_y": acc_y,
        "acc_z": acc_z,
        # Distancias
        "dist1": dist1,
        "dist2": dist2,
        "dist3": dist3,
    }

    return payload


def try_parse_image(
    line: str,
    image_buffer: Dict[str, Any],
) -> Optional[ImageFrame]:
    """
    Pipeline de imagen:

      B64_IMAGE_START ... B64_IMAGE_END
        -> reconstruir frame (np.ndarray BGR)
        -> generar TRES variantes:
            - data_url        : imagen original
            - data_url_colors : detección multi-color
            - data_url_model  : salida del modelo (YOLO, etc.) SOBRE LA IMAGEN CRUDA

    En particular:
      - 'deteccion on' solo aparece en data_url_colors.
      - data_url_model NO usa la imagen de colores como fallback.
    """

    # 1) Reconstruir desde las líneas B64_...
    img_raw = reconstruct_image_from_b64_line(line, image_buffer)
    if img_raw is None:
        # Todavía no se ha cerrado el bloque o no hay imagen válida
        return None

    # 2) Variante original -> base64 crudo
    raw_b64 = encode_image_to_b64(img_raw)

    # 3) Variante con detección multi-color (solo para "colors")
    img_colors = multi_color_detection(img_raw, color_names=None)
    colors_b64 = encode_image_to_b64(img_colors) if img_colors is not None else None

    # 4) Variante con modelo (YOLO, etc.) **SIEMPRE sobre la imagen cruda**
    #    y usando la ruta absoluta a app/best.pt
    img_model = model_detection(img_raw, model_path=MODEL_BEST_PATH)
    model_b64 = encode_image_to_b64(img_model) if img_model is not None else None

    # Si ninguna codificación salió bien, no enviamos nada
    if not any([raw_b64, colors_b64, model_b64]):
        return None

    # 5) Prefix data URL
    mime = "image/jpeg"  # asumimos JPEG; ajusta si usas otro formato
    data_url = f"data:{mime};base64,{raw_b64}" if raw_b64 else None
    data_url_colors = (
        f"data:{mime};base64,{colors_b64}" if colors_b64 is not None else None
    )
    data_url_model = (
        f"data:{mime};base64,{model_b64}" if model_b64 is not None else None
    )

    if data_url is None:
        # sin imagen original no tiene mucho sentido mandar frame
        return None

    # 6) Contador de frames (si lo quieres usar para debug)
    seq = image_buffer.get("seq", 0)
    image_buffer["seq"] = seq + 1

    # 7) Calcular longitud del payload crudo (para debug/estadísticas)
    raw_len = len(raw_b64) if raw_b64 is not None else 0

    ts = time.time()  # Epoch seconds (float), consistente con TelemetryRover

    frame = ImageFrame(
        timestamp=ts,
        data_url=data_url,
        raw_len=raw_len,
        data_url_colors=data_url_colors,
        data_url_model=data_url_model,
    )

    return frame
