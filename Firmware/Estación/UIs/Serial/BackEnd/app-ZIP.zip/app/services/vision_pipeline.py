# app/services/vision_pipeline.py
import base64
import os
from typing import Optional, Dict, Any, List

import cv2
import numpy as np

# Intentar importar YOLO, pero que no truene si no está instalado
try:
    from ultralytics import YOLO  # type: ignore
except ImportError:
    YOLO = None  # type: ignore


# ==========================
# Rangos de color (HSV)
# ==========================
COLOR_RANGES: Dict[str, Dict[str, Any]] = {
    "rojo": {
        "lower": [np.array([0, 100, 100]), np.array([170, 100, 100])],
        "upper": [np.array([10, 255, 255]), np.array([180, 255, 255])],
        "color_bgr": (0, 0, 255),
        "name": "Rojo",
    },
    "naranja": {
        "lower": np.array([5, 100, 100]),
        "upper": np.array([25, 255, 255]),
        "color_bgr": (0, 165, 255),
        "name": "Naranja",
    },
    "amarillo": {
        "lower": np.array([20, 100, 100]),
        "upper": np.array([30, 255, 255]),
        "color_bgr": (0, 255, 255),
        "name": "Amarillo",
    },
    "verde": {
        "lower": np.array([40, 100, 100]),
        "upper": np.array([80, 255, 255]),
        "color_bgr": (0, 255, 0),
        "name": "Verde",
    },
    "azul": {
        "lower": np.array([100, 100, 100]),
        "upper": np.array([130, 255, 255]),
        "color_bgr": (255, 0, 0),
        "name": "Azul",
    },
}


# ==========================
# 1) Reconstruir desde B64_IMAGE_START/END
# ==========================
def reconstruct_image_from_b64_line(
    text: str,
    image_buffer: Dict[str, Any],
) -> Optional[np.ndarray]:
    """
    Maneja el protocolo:
      B64_IMAGE_START
      <líneas base64...>
      B64_IMAGE_END

    Devuelve un np.ndarray (BGR) cuando se completó la imagen.
    Si todavía no se completa, devuelve None.
    """
    line = text.strip()

    # Inicio de bloque
    if line.startswith("B64_IMAGE_START"):
        image_buffer["collecting"] = True
        image_buffer["base64"] = ""
        return None

    # Fin de bloque
    if line.startswith("B64_IMAGE_END"):
        img = None
        if image_buffer.get("collecting") and image_buffer.get("base64"):
            b64 = image_buffer["base64"]
            try:
                img_data = base64.b64decode(b64)
                nparr = np.frombuffer(img_data, np.uint8)
                img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            except Exception:
                img = None

        # reset buffer
        image_buffer["collecting"] = False
        image_buffer["base64"] = ""
        return img

    # Línea intermedia (solo si estamos en bloque)
    if image_buffer.get("collecting"):
        prev = image_buffer.get("base64", "")
        image_buffer["base64"] = prev + line
        return None

    return None


# ==========================
# 2) Detección de color (una sola clase)
# ==========================
def colordetection(
    image: Optional[np.ndarray],
    color_name: str,
    min_area: Optional[int] = None,
    max_area: int = 500_000,
) -> Optional[np.ndarray]:
    """
    Detección de un solo color.
    Si min_area es None, se usa 200 píxeles por defecto.
    """
    if image is None or color_name not in COLOR_RANGES:
        return None

    # Calcular área mínima como 200 píxeles si no se especifica
    if min_area is None:
        min_area = 200  # 200 píxeles (más sensible que 25% del área)

    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    color_info = COLOR_RANGES[color_name]

    if color_name == "rojo":
        mask1 = cv2.inRange(hsv, color_info["lower"][0], color_info["upper"][0])
        mask2 = cv2.inRange(hsv, color_info["lower"][1], color_info["upper"][1])
        mask = cv2.bitwise_or(mask1, mask2)
    else:
        mask = cv2.inRange(hsv, color_info["lower"], color_info["upper"])

    kernel = np.ones((5, 5), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

    contours, _ = cv2.findContours(
        mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )
    filtered = [c for c in contours if min_area <= cv2.contourArea(c) <= max_area]

    image_color = image.copy()
    color_bgr = color_info["color_bgr"]
    color_name_display = color_info["name"]

    for contour in filtered:
        cv2.drawContours(image_color, [contour], -1, color_bgr, 2)
        x, y, w, h = cv2.boundingRect(contour)
        cv2.rectangle(image_color, (x, y), (x + w, y + h), color_bgr, 2)
        area = cv2.contourArea(contour)
        text = f"{color_name_display} ({int(area)})"
        cv2.putText(
            image_color,
            text,
            (x, y - 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            color_bgr,
            2,
        )

    return image_color


# ==========================
# 3) Detección multi-color (todos a la vez)
# ==========================
def multi_color_detection(
    image: Optional[np.ndarray],
    color_names: Optional[List[str]] = None,
    min_area: Optional[int] = None,
    max_area: int = 500_000,
) -> Optional[np.ndarray]:
    """
    Dibuja contornos para varios colores simultáneamente
    sobre una sola copia de la imagen.
    Si min_area es None, se usa 200 píxeles por defecto.
    """
    if image is None:
        return None

    # Calcular área mínima como 200 píxeles si no se especifica
    if min_area is None:
        min_area = 200  # 200 píxeles (más sensible que 25% del área)

    if not color_names:
        # Si no se especifica, usamos todos los colores definidos
        color_names = list(COLOR_RANGES.keys())

    out = image.copy()
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    kernel = np.ones((5, 5), np.uint8)

    for cname in color_names:
        if cname not in COLOR_RANGES:
            continue

        info = COLOR_RANGES[cname]

        if cname == "rojo":
            mask1 = cv2.inRange(hsv, info["lower"][0], info["upper"][0])
            mask2 = cv2.inRange(hsv, info["lower"][1], info["upper"][1])
            mask = cv2.bitwise_or(mask1, mask2)
        else:
            mask = cv2.inRange(hsv, info["lower"], info["upper"])

        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

        contours, _ = cv2.findContours(
            mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )
        filtered = [c for c in contours if min_area <= cv2.contourArea(c) <= max_area]

        color_bgr = info["color_bgr"]
        display_name = info["name"]

        for contour in filtered:
            cv2.drawContours(out, [contour], -1, color_bgr, 3)
            x, y, w, h = cv2.boundingRect(contour)
            cv2.rectangle(out, (x, y), (x + w, y + h), color_bgr, 3)
            area = cv2.contourArea(contour)
            text = f"{display_name} ({int(area)})"
            cv2.putText(
                out,
                text,
                (x, y - 10),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                color_bgr,
                2,
            )

    # Marcador visual sutil para depurar que el pipeline sí se aplicó
    cv2.putText(
        out,
        "deteccion on",
        (10, 18),  # esquina superior izquierda
        cv2.FONT_HERSHEY_SIMPLEX,
        0.5,  # pequeño
        (200, 200, 200),  # gris tenue
        1,  # trazo delgado
    )

    return out


# ==========================
# 4) YOLO (lazy load, opcional)
# ==========================
_YOLO_MODEL = None
_YOLO_MODEL_PATH: Optional[str] = None


def _load_yolo_model(model_path: Optional[str] = None):
    """
    Carga el modelo YOLO de forma lazy.
    Si no hay ultralytics instalado, devuelve None.
    """
    global _YOLO_MODEL, _YOLO_MODEL_PATH

    # Si no tenemos ultralytics instalado, no hay modelo
    if YOLO is None:
        print("[YOLO] ultralytics no está instalado; modelo desactivado.")
        return None

    # Ya cargado previamente
    if _YOLO_MODEL is not None:
        return _YOLO_MODEL

    possible_paths = [
        model_path,
        "best.pt",
        "model.pt",
        "weights/best.pt",
        "runs/detect/eva_detector/weights/best.pt",
        "runs/detect/train/weights/best.pt",
    ]

    for path in possible_paths:
        if path and os.path.exists(path):
            print(f"[YOLO] Cargando modelo desde: {path}")
            _YOLO_MODEL = YOLO(path)
            _YOLO_MODEL_PATH = path
            return _YOLO_MODEL

    print("[YOLO] No se encontró ningún archivo de pesos (best.pt / model.pt / ...).")
    return None


def model_detection(
    image: Optional[np.ndarray],
    model_path: Optional[str] = None,
) -> Optional[np.ndarray]:
    """
    Detección con YOLO.
    Siempre devuelve una imagen (nunca None) mientras 'image' no sea None.
    Se dibuja el texto 'model on' para confirmar que el pipeline de modelo se aplicó.
    """
    if image is None:
        return None

    # Copia base y marca visual
    out = image.copy()
    cv2.putText(
        out,
        "model on",
        (10, 18),  # esquina superior izquierda
        cv2.FONT_HERSHEY_SIMPLEX,
        0.5,
        (0, 255, 255),  # color visible (amarillo verdoso)
        1,
    )

    # Intentar cargar modelo YOLO
    model = _load_yolo_model(model_path)
    if model is None:
        # Sin modelo / sin ultralytics -> devolvemos solo la marca "model on"
        return out

    # Ejecutar inferencia
    try:
        results = model(image, verbose=False)
    except Exception as e:
        print(f"[YOLO] Error al hacer inferencia: {e}")
        # Si truena la inferencia, regresamos la imagen con "model on"
        return out

    # Dibujar bounding boxes (si existen) encima de 'out'
    detection_count = 0
    try:
        for r in results:
            if not hasattr(r, "boxes"):
                continue
            boxes_count = len(r.boxes)
            print(f"[YOLO] Encontradas {boxes_count} detecciones")
            
            for box in r.boxes:
                x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                conf = float(box.conf[0].cpu().numpy())
                cls = int(box.cls[0].cpu().numpy())
                label = model.names[cls]
                
                print(f"  - {label}: {conf*100:.1f}% confianza")

                cv2.rectangle(
                    out,
                    (int(x1), int(y1)),
                    (int(x2), int(y2)),
                    (0, 255, 0),
                    2,
                )
                text = f"{label} {conf*100:.1f}%"
                cv2.putText(
                    out,
                    text,
                    (int(x1), int(y1) - 10),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (0, 255, 0),
                    2,
                )
                detection_count += 1
        
        if detection_count == 0:
            print("[YOLO] No se detectaron objetos en la imagen")
    except Exception as e:
        print(f"[YOLO] Error al dibujar cajas: {e}")
        # Si algo falla al dibujar, devolvemos al menos la marca "model on"
        return out

    return out


# ==========================
# 5) Pipeline simple (sigue disponible si quieres usarlo)
# ==========================
def process_image_pipeline(
    image: Optional[np.ndarray],
    *,
    color_names: Optional[List[str]] = None,
    use_yolo: bool = False,
    model_path: Optional[str] = None,
) -> Optional[np.ndarray]:
    """
    Aplica:
      - detección multi-color (para varios colores a la vez)
      - y opcionalmente YOLO

    (Ya no lo usa rover_parser, pero lo dejamos por si luego quieres
     probar el pipeline completo desde otros lugares.)
    """
    if image is None:
        return None

    processed = image

    # Multi-color: si color_names es None, usa todos
    processed_multi = multi_color_detection(processed, color_names=color_names)
    if processed_multi is not None:
        processed = processed_multi

    if use_yolo:
        out = model_detection(processed, model_path)
        if out is not None:
            processed = out

    return processed


def encode_image_to_b64(
    image: Optional[np.ndarray],
    fmt: str = ".jpg",
) -> Optional[str]:
    """
    Codifica la imagen a JPEG base64.
    Devuelve None si image es None o si cv2.imencode falla.
    """
    if image is None:
        return None
    ok, buffer = cv2.imencode(fmt, image)
    if not ok:
        return None
    return base64.b64encode(buffer.tobytes()).decode("ascii")


# ==========================
# 6) Helper extra: overlay de texto (como en tu nuevo código)
# ==========================
def text(image: Optional[np.ndarray]) -> Optional[np.ndarray]:
    """
    Agrega texto 'HOLA' en la esquina superior izquierda.
    """
    if image is None:
        return None
    image_text = image.copy()
    cv2.putText(
        image_text,
        "HOLA",
        (10, 30),
        cv2.FONT_HERSHEY_SIMPLEX,
        1,
        (255, 255, 255),
        2,
    )
    return image_text
